#!/usr/bin/env python3
"""Regenerate every report figure with English labels (the server has no CJK font)."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch  # noqa: E402

RESULTS = Path("/root/hw3/results")
OUT = Path("/root/hw3/report/fig")
OUT.mkdir(parents=True, exist_ok=True)

GROUPS = [
    ("A\ndefault\nmor=5", "A_default"),
    ("B1\np2c\nmor=16", "B_candidates/candidate-1"),
    ("B2\np2c\nmor=64", "B_candidates/candidate-2"),
    ("C\nconsistent\nhash", "C_affinity"),
    ("D\nprefix\naffinity", "D_improved"),
]


def summaries():
    out = []
    for label, rel in GROUPS:
        path = RESULTS / rel / "summary.json"
        if path.exists():
            out.append((label, json.loads(path.read_text())))
    return out


def fig_main(rows) -> None:
    labels = [r[0] for r in rows]
    throughput = [r[1]["throughput_rps"] for r in rows]
    cache = [r[1]["cache_hit_rate"] * 100 for r in rows]
    ttft = [r[1]["ttft_s"]["p95"] for r in rows]
    latency = [r[1]["latency_s"]["p95"] for r in rows]

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.4))
    bars = axes[0].bar(labels, throughput, color="#2f6fed")
    axes[0].set_title("Throughput (requests/s)")
    axes[0].bar_label(bars, fmt="%.1f", fontsize=8.5)
    axes[0].set_ylim(0, max(throughput) * 1.18)

    bars = axes[1].bar(labels, cache, color="#2fa36b")
    axes[1].set_title("Prefix cache hit rate (%)")
    axes[1].set_ylim(0, 105)
    axes[1].bar_label(bars, fmt="%.1f", fontsize=8.5)

    x = np.arange(len(labels))
    width = 0.38
    b1 = axes[2].bar(x - width / 2, ttft, width, label="TTFT p95", color="#e08a1e")
    b2 = axes[2].bar(x + width / 2, latency, width, label="E2E p95", color="#b8474b")
    axes[2].set_xticks(x)
    axes[2].set_xticklabels(labels, fontsize=8)
    axes[2].set_title("Tail latency (s)")
    axes[2].legend(fontsize=8.5)
    axes[2].set_ylim(0, max(latency) * 1.18)
    axes[2].bar_label(b1, fmt="%.1f", fontsize=7.5, padding=1)
    axes[2].bar_label(b2, fmt="%.1f", fontsize=7.5, padding=1)

    for ax in axes:
        ax.tick_params(labelsize=8.5)
        ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(OUT / "fig_main.png", dpi=150)
    plt.close(fig)


def fig_backends(rows) -> None:
    fig, axes = plt.subplots(1, len(rows), figsize=(3.2 * len(rows), 3.4), sharey=True)
    if len(rows) == 1:
        axes = [axes]
    for ax, (label, summary) in zip(axes, rows):
        dist = summary["backend_distribution"]
        keys = sorted(dist)
        total = sum(dist.values())
        shares = [dist[k] / total * 100 for k in keys]
        bars = ax.bar(["b0", "b1", "b2", "b3"], shares, color="#4b6cb7")
        ax.set_title(label.replace("\n", " "), fontsize=9)
        ax.set_ylim(0, 100)
        ax.grid(axis="y", alpha=0.25)
        ax.bar_label(bars, fmt="%.0f%%", fontsize=8)
    axes[0].set_ylabel("share of measured requests (%)", fontsize=9)
    fig.tight_layout()
    fig.savefig(OUT / "fig_backends.png", dpi=150)
    plt.close(fig)


def fig_latency_cdf() -> None:
    """CDF of end-to-end latency per group, straight from requests.csv."""

    import csv

    fig, ax = plt.subplots(figsize=(7.2, 4.2))
    colors = {
        "A_default": "#2f6fed",
        "B_candidates/candidate-1": "#e08a1e",
        "B_candidates/candidate-2": "#2fa36b",
        "C_affinity": "#b8474b",
        "D_improved": "#7b4bb7",
    }
    names = {
        "A_default": "A default mor=5",
        "B_candidates/candidate-1": "B1 p2c mor=16",
        "B_candidates/candidate-2": "B2 p2c mor=64",
        "C_affinity": "C consistent hash",
        "D_improved": "D prefix affinity",
    }
    for rel, color in colors.items():
        path = RESULTS / rel / "requests.csv"
        if not path.exists():
            continue
        with path.open(newline="", encoding="utf-8") as handle:
            values = sorted(
                float(row["latency_s"]) for row in csv.DictReader(handle) if row["latency_s"]
            )
        if not values:
            continue
        ys = np.arange(1, len(values) + 1) / len(values)
        ax.plot(values, ys, label=names[rel], color=color, linewidth=1.6)
    ax.set_xlabel("end-to-end latency (s)")
    ax.set_ylabel("cumulative fraction of requests")
    ax.set_title("Latency CDF over the 2048 measured requests")
    ax.grid(alpha=0.3)
    ax.legend(fontsize=8.5, loc="lower right")
    fig.tight_layout()
    fig.savefig(OUT / "fig_latency_cdf.png", dpi=150)
    plt.close(fig)


def fig_timeline() -> None:
    """Backend share over time, 2 s buckets, for A, C and D."""

    import csv
    from collections import Counter, defaultdict

    picks = [("A_default", "A default mor=5"), ("C_affinity", "C consistent hash"), ("D_improved", "D prefix affinity")]
    fig, axes = plt.subplots(len(picks), 1, figsize=(10, 1.9 * len(picks)), sharex=True)
    for ax, (rel, title) in zip(axes, picks):
        path = RESULTS / rel / "requests.csv"
        if not path.exists():
            continue
        with path.open(newline="", encoding="utf-8") as handle:
            records = list(csv.DictReader(handle))
        buckets: dict[int, Counter] = defaultdict(Counter)
        for record in records:
            buckets[int(float(record["actual_send_s"]) // 2)][record["backend"]] += 1
        keys = sorted(buckets)
        bottom = np.zeros(len(keys))
        for index, backend in enumerate(sorted({r["backend"] for r in records})):
            values = np.array([buckets[k].get(backend, 0) for k in keys], dtype=float)
            ax.bar(keys, values, bottom=bottom, width=0.9, label=f"backend {index}", color=f"C{index}")
            bottom += values
        ax.set_ylabel(title, fontsize=8)
        ax.tick_params(labelsize=7)
    axes[0].legend(fontsize=7.5, ncol=4)
    axes[-1].set_xlabel("time in the measured phase (2 s buckets)")
    fig.tight_layout()
    fig.savefig(OUT / "fig_timeline.png", dpi=150)
    plt.close(fig)


def fig_topology() -> None:
    fig, ax = plt.subplots(figsize=(12, 4.3))
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 4.3)
    ax.axis("off")

    def box(x, y, w, h, text, color, size=9.0):
        ax.add_patch(
            FancyBboxPatch(
                (x, y), w, h, boxstyle="round,pad=0.06", linewidth=1.1,
                edgecolor="#274b8f", facecolor=color,
            )
        )
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=size)

    def arrow(x1, y1, x2, y2, ls="-"):
        ax.add_patch(
            FancyArrowPatch(
                (x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=12,
                color="#274b8f", linestyle=ls, linewidth=1.1,
            )
        )

    box(0.1, 1.55, 1.7, 1.15, "Client\n2048 measured\nrequests", "#ffe9c7")
    box(2.3, 1.55, 2.2, 1.15, "Ray Serve HTTP Proxy\nhead node, :8000\nPOST /generate", "#dbe7ff")
    ax.text(3.4, 1.15, "request router picks a replica\n(p2c / consistent hash / custom)",
            ha="center", fontsize=8.0, color="#274b8f")
    arrow(1.8, 2.12, 2.3, 2.12)
    for i in range(4):
        x = 5.0 + i * 1.72
        box(x, 2.5, 1.55, 0.95, f"Replica {i}\nworker node {i + 1}", "#dff2e1")
        box(x, 0.6, 1.55, 0.95, f"SGLang {i}\nGPU {i}", "#f7dede")
        arrow(4.5, 2.75, x + 0.77, 3.45, ls="--")
        arrow(x + 0.77, 2.5, x + 0.77, 1.55)
    ax.text(6.0, 3.95, "Ray logical cluster: 1 head node + 4 worker nodes", ha="center",
            fontsize=9.5, color="#274b8f")
    ax.text(6.0, 0.18, "response headers: X-Ray-Replica-ID / X-Ray-Node-ID / X-SGLang-Backend",
            ha="center", fontsize=8.4, color="#555555")
    fig.tight_layout()
    fig.savefig(OUT / "fig_topology.png", dpi=150)
    plt.close(fig)


def main() -> int:
    rows = summaries()
    fig_main(rows)
    fig_backends(rows)
    fig_latency_cdf()
    fig_timeline()
    fig_topology()
    print("figures:", sorted(p.name for p in OUT.glob("*.png")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
