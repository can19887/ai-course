"""Ray cluster construction: 1 head node + 4 logical worker nodes.

The whole four-replica topology is created inside one OS process with
``ray.cluster_utils.Cluster``: one head node plus four worker nodes.  Each
worker node owns exactly one GPU, one SGLang server and one Ray Serve replica.

Every worker node is started with a private custom resource
``worker_<i> = 1.0`` (declared on the ``raylet`` command line, so no private
Ray API is needed).  That resource is what pins

* placement-group bundle ``i`` -> worker node ``i`` (hence replica ``i``), and
* SGLang server ``i``        -> worker node ``i``.
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

# Must be set before ray is imported.
os.environ.setdefault("RAY_SERVE_DISABLE_PLACEMENT_GROUP", "1")
os.environ.setdefault("RAY_SERVE_SESSION_ID_HEADER_KEY", "x-session-id")

import ray  # noqa: E402
from ray.cluster_utils import Cluster  # noqa: E402
from ray.util.placement_group import placement_group  # noqa: E402

NUM_WORKERS = 4
HEAD_CPUS = 2
WORKER_CPUS = 4
SGLANG_PORT_BASE = 30000
SGLANG_PORT_STEP = 10


def worker_resource(index: int) -> str:
    """Custom resource name that identifies worker node ``index`` (1-based)."""

    return f"worker_{index}"


def worker_label(index: int) -> Dict[str, str]:
    """Node label attached to worker node ``index`` (1-based)."""

    return {"hw3_worker": str(index)}


@dataclass
class NodeInfo:
    """Static description of one logical node."""

    node_id: str
    node_ip: str
    index: int  # 0 = head, 1..4 = workers
    role: str  # "head" | "worker"
    resources: Dict[str, float]
    gpu: Optional[int] = None
    backend: Optional[str] = None
    sglang_port: Optional[int] = None
    sglang_url: Optional[str] = None
    worker_index: Optional[int] = None
    labels: Dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)

    @property
    def pin(self) -> str:
        """Resource key that pins work to exactly this node."""

        if self.role == "worker":
            return worker_resource(self.index)
        return "node:__internal_head__"

    @property
    def label_selector(self) -> List[Dict[str, str]]:
        """Label selector that selects exactly this worker node."""

        return [
            {"key": "hw3_worker", "operator": "In", "values": [str(self.index)]}
        ]


@dataclass
class Topology:
    """Whole-cluster topology description, persisted to topology.json."""

    created_at: float = field(default_factory=time.time)
    ray_version: str = ""
    nodes: List[NodeInfo] = field(default_factory=list)
    placement_group_name: str = "hw3-replicas"

    @property
    def head(self) -> NodeInfo:
        return next(n for n in self.nodes if n.role == "head")

    @property
    def workers(self) -> List[NodeInfo]:
        return sorted(
            (n for n in self.nodes if n.role == "worker"), key=lambda n: n.index
        )

    def to_dict(self) -> dict:
        return {
            "created_at": self.created_at,
            "ray_version": self.ray_version,
            "placement_group_name": self.placement_group_name,
            "nodes": [n.to_dict() for n in self.nodes],
        }

    def save(self, path: str | Path) -> None:
        Path(path).write_text(
            json.dumps(self.to_dict(), indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )


def _alive_nodes() -> List[dict]:
    return [n for n in ray.nodes() if n.get("Alive")]


def _wait_for_nodes(expected: int, timeout_s: float = 240.0) -> None:
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        if len(_alive_nodes()) >= expected:
            return
        time.sleep(0.5)
    raise TimeoutError(f"only {len(_alive_nodes())}/{expected} nodes came up")


def _wait_for_resource(resource: str, timeout_s: float = 120.0) -> dict:
    """Wait until some alive node reports ``resource`` with a positive amount."""

    deadline = time.time() + timeout_s
    while time.time() < deadline:
        for node in _alive_nodes():
            if float(node.get("Resources", {}).get(resource, 0.0)) > 0:
                return node
        time.sleep(0.5)
    raise TimeoutError(f"node resource {resource} never appeared")


def start_cluster(
    num_workers: int = NUM_WORKERS,
    *,
    gcs_port: int = 6379,
    verbose: bool = True,
) -> tuple[Cluster, Topology]:
    """Create the logical Ray cluster: 1 head node + ``num_workers`` workers."""

    cluster = None
    last_error: Optional[Exception] = None
    for offset in (0, 100, 200, 300):
        port = gcs_port + offset
        try:
            cluster = Cluster(
                initialize_head=True,
                head_node_args={
                    "num_cpus": HEAD_CPUS,
                    "gcs_server_port": port,
                    "include_dashboard": False,
                },
                shutdown_at_exit=False,
            )
            break
        except Exception as exc:  # port already in use etc.
            last_error = exc
            print(f"[cluster] head node on gcs port {port} failed: {exc!r}", flush=True)
            cluster = None
    if cluster is None:
        raise RuntimeError(f"could not start the Ray head node: {last_error!r}")

    ray.init(
        address=cluster.address,
        log_to_driver=False,
        ignore_reinit_error=True,
        include_dashboard=False,
    )
    _wait_for_nodes(1)

    # Worker nodes are added one at a time with their own custom resource and
    # label, so both the placement group and the SGLang actors can be pinned
    # exactly to a node.
    workers: List[dict] = []
    for index in range(1, num_workers + 1):
        cluster.add_node(
            num_cpus=WORKER_CPUS,
            num_gpus=0,
            resources={worker_resource(index): 1.0},
            labels=worker_label(index),
        )
        workers.append(_wait_for_resource(worker_resource(index)))
    _wait_for_nodes(1 + num_workers)

    nodes = {n["NodeID"]: n for n in _alive_nodes()}
    head = next(
        n for n in _alive_nodes() if "node:__internal_head__" in n.get("Resources", {})
    )
    node_ids = [head["NodeID"]] + [w["NodeID"] for w in workers]
    # A single worker_index -> node_id mapping is exposed to the placement
    # group / SGLang actors; the driver also needs an ip to reach every node,
    # so give each logical node its own loopback alias.
    head_ip = "127.0.0.1"
    topology = Topology(ray_version=ray.__version__)
    topology.nodes.append(
        NodeInfo(
            node_id=head["NodeID"],
            node_ip=head_ip,
            index=0,
            role="head",
            resources={
                key: float(value)
                for key, value in head.get("Resources", {}).items()
                if key in {"CPU", "node:__internal_head__"}
            },
        )
    )
    for index in range(1, num_workers + 1):
        node = workers[index - 1]
        port = SGLANG_PORT_BASE + (index - 1) * SGLANG_PORT_STEP
        info = NodeInfo(
            node_id=node["NodeID"],
            node_ip=head_ip,
            index=index,
            role="worker",
            resources={
                key: float(value)
                for key, value in node.get("Resources", {}).items()
                if key in {"CPU", worker_resource(index)}
            },
            gpu=index - 1,
            backend=f"sglang-{index - 1}",
            sglang_port=port,
            sglang_url=f"http://{head_ip}:{port}",
            worker_index=index,
            labels=worker_label(index),
        )
        topology.nodes.append(info)

    if verbose:
        print("[cluster] topology:", json.dumps(topology.to_dict(), indent=2), flush=True)
    return cluster, topology


def create_placement_group(topology: Topology, name: str = "hw3-replicas"):
    """Bundle i is pinned to worker node i, so replica i lands on worker i."""

    bundles = [{worker.pin: 0.001, "CPU": 0.001} for worker in topology.workers]
    pg = placement_group(bundles, strategy="SPREAD", name=name, lifetime=None)
    ray.get(pg.ready(), timeout=180)
    return pg


def stop_cluster(cluster: Optional[Cluster]) -> None:
    try:
        ray.shutdown()
    except Exception:
        pass
    if cluster is not None:
        try:
            cluster.shutdown()
        except Exception:
            pass
