"""Read the per-request CSVs and produce the aggregated numbers of the report.

Only the fixed workload is summarised; every headline number in ``report.md``
comes from here so the text can never drift away from the raw files.
"""

from __future__ import annotations

import csv
import json
import math
import statistics
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

DEFAULT_GROUPS = [
    ("A", "A_default"),
    ("B1", "B_candidates/candidate-1"),
    ("B2", "B_candidates/candidate-2"),
    ("C", "C_affinity"),
    ("D", "D_improved"),
]


def _pearson(xs: List[float], ys: List[float]) -> Optional[float]:
    n = len(xs)
    if n < 3:
        return None
    mx = sum(xs) / n
    my = sum(ys) / n
    num = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    dx = math.sqrt(sum((x - mx) ** 2 for x in xs))
    dy = math.sqrt(sum((y - my) ** 2 for y in ys))
    if dx == 0 or dy == 0:
        return None
    return num / (dx * dy)


def _rank(values: List[float]) -> List[float]:
    order = sorted(range(len(values)), key=lambda i: values[i])
    ranks = [0.0] * len(values)
    for position, index in enumerate(order):
        ranks[index] = float(position) + 1.0
    return ranks


def _spearman(xs: List[float], ys: List[float]) -> Optional[float]:
    if len(xs) < 3:
        return None
    return _pearson(_rank(xs), _rank(ys))


def load_requests(path: Path) -> List[Dict[str, Any]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        for key in (
            "ttft_s",
            "tpot_s",
            "latency_s",
            "dispatch_lag_s",
            "client_queue_s",
            "actual_send_s",
        ):
            row[key] = float(row[key]) if row.get(key) not in (None, "") else None
        for key in (
            "input_tokens",
            "prompt_tokens",
            "cached_tokens",
            "output_tokens",
            "requested_output_tokens",
        ):
            row[key] = int(float(row[key])) if row.get(key) not in (None, "") else 0
    return rows


def pct(values: Iterable[float], q: float) -> Optional[float]:
    clean = sorted(v for v in values if v is not None)
    if not clean:
        return None
    index = max(0, math.ceil(q * len(clean)) - 1)
    return clean[min(index, len(clean) - 1)]


def describe_group(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    ttft = [r["ttft_s"] for r in rows if r["ttft_s"] is not None]
    latency = [r["latency_s"] for r in rows if r["latency_s"] is not None]
    prompt = sum(r["prompt_tokens"] for r in rows)
    cached = sum(r["cached_tokens"] for r in rows)
    out: Dict[str, Any] = {
        "requests": len(rows),
        "ttft_p50": pct(ttft, 0.50),
        "ttft_p95": pct(ttft, 0.95),
        "ttft_p99": pct(ttft, 0.99),
        "latency_p50": pct(latency, 0.50),
        "latency_p95": pct(latency, 0.95),
        "latency_p99": pct(latency, 0.99),
        "prompt_tokens": prompt,
        "cached_tokens": cached,
        "cache_hit_rate": (cached / prompt) if prompt else None,
        "computed_prefill_tokens": prompt - cached,
        "backend_requests": dict(sorted(Counter(r["backend"] for r in rows).items())),
        "family_requests": dict(
            sorted(Counter(r["prefix_family"] for r in rows).items())
        ),
    }
    # per-family affinity: how concentrated is each family on one backend?
    per_family: Dict[str, Counter] = defaultdict(Counter)
    per_family_cache: Dict[str, List[int]] = defaultdict(list)
    per_family_ttft: Dict[str, List[float]] = defaultdict(list)
    for row in rows:
        per_family[row["prefix_family"]][row["backend"]] += 1
        per_family_cache[row["prefix_family"]].append(row["cached_tokens"])
        if row["ttft_s"] is not None:
            per_family_ttft[row["prefix_family"]].append(row["ttft_s"])
    purity = [
        counter.most_common(1)[0][1] / sum(counter.values())
        for counter in per_family.values()
    ]
    out["family_affinity_mean"] = statistics.fmean(purity) if purity else None
    out["family_affinity_min"] = min(purity) if purity else None
    out["families"] = len(per_family)

    # correlation between reuse (cached tokens) and TTFT
    xs = [float(r["cached_tokens"]) for r in rows]
    ys = [float(r["ttft_s"]) for r in rows if r["ttft_s"] is not None]
    out["corr_cached_ttft"] = _pearson(xs[: len(ys)], ys)
    out["corr_cached_ttft_spearman"] = _spearman(xs[: len(ys)], ys)

    # hottest family behaviour (the superhot family has 768 measured requests)
    fam_counts = Counter(r["prefix_family"] for r in rows)
    hot_family, hot_count = fam_counts.most_common(1)[0]
    hot_rows = [r for r in rows if r["prefix_family"] == hot_family]
    out["hot_family"] = hot_family
    out["hot_family_requests"] = hot_count
    out["hot_family_backends"] = dict(sorted(Counter(r["backend"] for r in hot_rows).items()))
    hot_latency = [r["latency_s"] for r in hot_rows if r["latency_s"] is not None]
    out["hot_family_latency_p95"] = pct(hot_latency, 0.95)
    out["hot_family_share"] = hot_count / len(rows)

    # load distribution over time: backend requests per 2s bucket
    buckets: Dict[int, Counter] = defaultdict(Counter)
    for row in rows:
        bucket = int(row["actual_send_s"] // 2)
        buckets[bucket][row["backend"]] += 1
    out["load_timeline"] = {
        str(k): dict(sorted(v.items())) for k, v in sorted(buckets.items())
    }

    # phase breakdown
    phases: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in rows:
        phases[row["traffic_phase"]].append(row)
    out["phases"] = {}
    for phase, items in phases.items():
        phase_ttft = [r["ttft_s"] for r in items if r["ttft_s"] is not None]
        phase_latency = [r["latency_s"] for r in items if r["latency_s"] is not None]
        phase_prompt = sum(r["prompt_tokens"] for r in items)
        phase_cached = sum(r["cached_tokens"] for r in items)
        out["phases"][phase] = {
            "requests": len(items),
            "cache_hit_rate": (phase_cached / phase_prompt) if phase_prompt else None,
            "ttft_p95": pct(phase_ttft, 0.95),
            "latency_p95": pct(phase_latency, 0.95),
            "throughput": len(items) / (items[-1]["actual_send_s"] or 1),
        }

    # popularity tier breakdown
    tiers: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in rows:
        tiers[row["popularity_tier"]].append(row)
    out["tiers"] = {}
    for tier, items in tiers.items():
        tier_ttft = [r["ttft_s"] for r in items if r["ttft_s"] is not None]
        tier_latency = [r["latency_s"] for r in items if r["latency_s"] is not None]
        tier_prompt = sum(r["prompt_tokens"] for r in items)
        tier_cached = sum(r["cached_tokens"] for r in items)
        families = Counter(r["prefix_family"] for r in items)
        out["tiers"][tier] = {
            "requests": len(items),
            "families": len(families),
            "cache_hit_rate": (tier_cached / tier_prompt) if tier_prompt else None,
            "ttft_p50": pct(tier_ttft, 0.50),
            "ttft_p95": pct(tier_ttft, 0.95),
            "latency_p95": pct(tier_latency, 0.95),
            "backend_requests": dict(sorted(Counter(r["backend"] for r in items).items())),
        }
    return out


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", default="/root/hw3/results")
    parser.add_argument("--out", default="/root/hw3/report/numbers.json")
    args = parser.parse_args()

    results_root = Path(args.results)
    numbers: Dict[str, Any] = {"groups": {}}
    for label, rel in DEFAULT_GROUPS:
        run_dir = results_root / rel
        if not (run_dir / "requests.csv").exists():
            continue
        rows = load_requests(run_dir / "requests.csv")
        summary = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
        meta_path = run_dir / "run_meta.json"
        meta = json.loads(meta_path.read_text(encoding="utf-8")) if meta_path.exists() else {}
        entry = describe_group(rows)
        entry["summary"] = {
            key: summary.get(key)
            for key in (
                "run_name",
                "router_name",
                "max_ongoing_requests",
                "model",
                "successful",
                "failed",
                "incomplete",
                "throughput_rps",
                "elapsed_s",
                "planned_duration_s",
                "offered_rate_rps",
                "ttft_s",
                "latency_s",
                "tpot_s",
                "dispatch_lag_s",
                "client_queue_s",
                "replica_distribution",
                "node_distribution",
                "backend_distribution",
                "validation_errors",
            )
        }
        entry["run_meta"] = {
            "replay_seconds": meta.get("replay_seconds"),
            "gpu_summary": meta.get("gpu_summary"),
            "flush_cache_ok": meta.get("flush_cache_ok"),
            "verification": meta.get("verification"),
            "policy": meta.get("policy"),
        }
        numbers["groups"][label] = entry
        print(f"[numbers] {label}: {run_dir}")

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(
        json.dumps(numbers, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"[numbers] wrote {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
