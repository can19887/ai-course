"""Ray Serve HTTP entry point: proxy -> replica 0..3 -> SGLang backend 0..3.

One deployment with four replicas.  Each replica is pinned to one logical Ray
worker node (through the placement group created in :mod:`hw3.cluster`) and
therefore to exactly one SGLang backend, whose GPU sits on that same node.

The client only ever talks to ``POST /generate`` on the Ray Serve HTTP proxy.

NOTE: this module deliberately does *not* use ``from __future__ import
annotations``; FastAPI resolves the ``Request`` annotation at runtime and would
otherwise treat the request body as a required query parameter.
"""

import asyncio
import json
import os
from pathlib import Path
from typing import Any, AsyncGenerator, Dict, List, Optional

import aiohttp
import ray
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response, StreamingResponse
from ray import serve
from ray.serve.config import GangPlacementStrategy, GangSchedulingConfig, RequestRouterConfig

TOPOLOGY_PATH = os.environ.get("HW3_TOPOLOGY", "/root/hw3/run/topology.json")

# Headers the workload generator sends and the assignment requires us to
# forward to SGLang.
FORWARD_HEADERS = ("X-Session-Id", "X-Workload-Request-ID", "X-Prefix-Family")

app = FastAPI()


def load_topology() -> Dict[str, Dict[str, Any]]:
    path = Path(TOPOLOGY_PATH)
    if not path.exists():
        raise RuntimeError(
            f"topology file {TOPOLOGY_PATH} not found; start the cluster first"
        )
    data = json.loads(path.read_text(encoding="utf-8"))
    return {node["node_id"]: node for node in data["nodes"]}


@serve.deployment(
    name="RayServeHTTP",
    num_replicas=4,
    max_ongoing_requests=5,
    # The replica only proxies bytes: it owns no GPU and very little CPU.  The
    # gang covers all four replicas and SPREAD keeps them on four different
    # logical worker nodes; hw3.run_group verifies the mapping after deploy and
    # redeploys if Ray ever packs two replicas onto one node.
    ray_actor_options={"num_cpus": 0.2},
    gang_scheduling_config=GangSchedulingConfig(
        gang_size=4,
        gang_placement_strategy=GangPlacementStrategy.SPREAD,
    ),
)
@serve.ingress(app)
class RayServeHTTP:
    def __init__(self) -> None:
        self._topology = load_topology()
        self._node_id = ray.get_runtime_context().get_node_id()
        self._replica_id = ray.get_runtime_context().get_actor_id()
        node = self._topology.get(self._node_id)
        if node is None:
            raise RuntimeError(
                f"replica landed on unknown node {self._node_id}; topology="
                f"{sorted(self._topology)}"
            )
        self._gpu = node["gpu"]
        self._backend = node["backend"]
        self._backend_url = node["sglang_url"]
        self._session: Optional[aiohttp.ClientSession] = None
        print(
            f"[replica] replica_id={self._replica_id} node_id={self._node_id} "
            f"backend={self._backend} gpu={self._gpu} url={self._backend_url}",
            flush=True,
        )

    # ------------------------------------------------------------------ hooks
    def record_replica_metadata(self) -> Dict[str, Any]:
        """Static metadata surfaced to the Serve dashboard."""

        return {
            "backend": self._backend,
            "gpu": self._gpu,
            "node_id": self._node_id,
            "backend_url": self._backend_url,
        }

    def record_routing_stats(self) -> Dict[str, Any]:
        return {
            "backend": self._backend,
            "gpu": self._gpu,
            "sglang_url": self._backend_url,
        }

    # ---------------------------------------------------------------- helper
    def _routing_headers(self) -> Dict[str, str]:
        return {
            "X-Ray-Replica-ID": str(self._replica_id),
            "X-Ray-Node-ID": str(self._node_id),
            "X-SGLang-Backend": str(self._backend),
        }

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            connector = aiohttp.TCPConnector(
                limit=0,
                keepalive_timeout=600,
                force_close=False,
                enable_cleanup_closed=False,
            )
            self._session = aiohttp.ClientSession(
                connector=connector,
                timeout=aiohttp.ClientTimeout(total=None, sock_connect=30),
                auto_decompress=False,
            )
        return self._session

    # ------------------------------------------------------------- endpoints
    @app.get("/health")
    async def health(self) -> Dict[str, Any]:
        return {
            "status": "ok",
            "replica_id": self._replica_id,
            "node_id": self._node_id,
            "backend": self._backend,
            "gpu": self._gpu,
        }

    @app.post("/generate")
    async def generate(self, request: Request) -> Response:
        raw = await request.body()
        try:
            payload = json.loads(raw)
        except Exception as exc:
            return JSONResponse(
                status_code=400,
                content={"error": "invalid_json_body", "detail": repr(exc)},
            )
        # SGLang's /generate validates the body against GenerateReqInput and
        # rejects raw bytes, so the replica forwards the decoded JSON object
        # and lets aiohttp set the Content-Type header.
        headers = self._routing_headers()
        for name in FORWARD_HEADERS:
            value = request.headers.get(name)
            if value:
                headers[name] = value

        session = await self._get_session()

        async def body_stream() -> AsyncGenerator[bytes, None]:
            try:
                async with session.post(
                    f"{self._backend_url}/generate", json=payload, headers=headers
                ) as upstream:
                    if upstream.status != 200:
                        detail = (await upstream.read())[:500]
                        yield (
                            "event: error\ndata: "
                            + json.dumps(
                                {
                                    "error": "sglang_error",
                                    "status": upstream.status,
                                    "detail": detail.decode("utf-8", "replace"),
                                }
                            )
                            + "\n\n"
                        ).encode()
                        return
                    async for chunk in upstream.content.iter_chunked(8192):
                        yield chunk
            except asyncio.CancelledError:  # client went away
                raise
            except Exception as exc:  # pragma: no cover - transport failure
                yield (
                    "event: error\ndata: "
                    + json.dumps({"error": "proxy_exception", "detail": repr(exc)})
                    + "\n\n"
                ).encode()

        return StreamingResponse(
            body_stream(),
            status_code=200,
            media_type="text/event-stream",
            headers=headers,
        )

    @app.get("/__topology")
    async def topology(self) -> JSONResponse:
        return JSONResponse(
            {
                "replica_id": self._replica_id,
                "node_id": self._node_id,
                "backend": self._backend,
                "gpu": self._gpu,
                "backend_url": self._backend_url,
            }
        )


def build_app(
    *,
    max_ongoing_requests: int = 5,
    request_router_class: Any = None,
    request_router_kwargs: Optional[Dict[str, Any]] = None,
    routing_stats_period_s: float = 10.0,
) -> Any:
    """Bind the deployment with the routing policy of one experiment group.

    ``request_router_class=None`` keeps Ray Serve's stock router (the power of
    two choices router) and lets its default configuration apply.
    """

    options: Dict[str, Any] = {"max_ongoing_requests": max_ongoing_requests}
    if request_router_class is not None:
        options["request_router_config"] = RequestRouterConfig(
            request_router_class=request_router_class,
            request_router_kwargs=request_router_kwargs or {},
            request_routing_stats_period_s=routing_stats_period_s,
        )
    return RayServeHTTP.options(**options).bind()
