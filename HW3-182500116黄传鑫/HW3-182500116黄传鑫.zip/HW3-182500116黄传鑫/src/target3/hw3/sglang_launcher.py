"""Launch and control one SGLang server per worker node (one per GPU).

Every worker node runs exactly one ``sglang.launch_server`` process pinned to
its own GPU through ``CUDA_VISIBLE_DEVICES``.  The servers are started from Ray
tasks so that they live on the logical worker nodes created in
:mod:`hw3.cluster`.
"""

from __future__ import annotations

import asyncio
import json
import os
import signal
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

import aiohttp
import ray

from .cluster import NodeInfo, Topology

DEFAULT_MODEL_PATH = "/root/autodl-tmp/models/Qwen3-4B-Instruct-2507"
DEFAULT_MODEL_LABEL = "Qwen/Qwen3-4B-Instruct-2507"
LOG_DIR = "/root/hw3/logs"


def sglang_server_args(
    model_path: str = DEFAULT_MODEL_PATH,
    *,
    port: int,
    attention_backend: str = "flashinfer",
    page_size: int = 1,
    mem_fraction_static: float = 0.75,
    max_running_requests: int = 256,
    chunked_prefill_size: int = 4096,
    max_total_tokens: Optional[int] = None,
    extra: Optional[List[str]] = None,
) -> List[str]:
    """Canonical SGLang flags; identical for every experiment group."""

    args = [
        sys.executable,
        "-m",
        "sglang.launch_server",
        "--model-path",
        model_path,
        "--host",
        "0.0.0.0",
        "--port",
        str(port),
        "--attention-backend",
        attention_backend,
        "--page-size",
        str(page_size),
        "--mem-fraction-static",
        str(mem_fraction_static),
        "--max-running-requests",
        str(max_running_requests),
        "--chunked-prefill-size",
        str(chunked_prefill_size),
        "--schedule-policy",
        "fcfs",
        "--enable-cache-report",
        "--enable-metrics",
        "--trust-remote-code",
        "--log-level",
        "warning",
    ]
    if max_total_tokens is not None:
        args += ["--max-total-tokens", str(max_total_tokens)]
    if extra:
        args += list(extra)
    return args


@ray.remote(num_cpus=0.2)
class SglangServerActor:
    """Detached actor that supervises one SGLang server on its own node."""

    def __init__(self, spec_json: str) -> None:
        spec = json.loads(spec_json)
        self.log_path = spec["log_path"]
        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"
        cmd = spec["args"]
        os.makedirs(os.path.dirname(self.log_path), exist_ok=True)
        with open(self.log_path, "ab") as log:
            log.write(("CMD " + " ".join(cmd) + "\n").encode())
            log.flush()
            self._log = log
            self._proc = subprocess.Popen(
                cmd,
                stdout=log,
                stderr=subprocess.STDOUT,
                env=env,
                start_new_session=True,
            )

    def alive(self) -> bool:
        return self._proc.poll() is None

    def returncode(self) -> Optional[int]:
        return self._proc.poll()

    def tail(self, lines: int = 40) -> str:
        try:
            with open(self.log_path, "rb") as handle:
                data = handle.read()
            return b"\n".join(data.splitlines()[-lines:]).decode("utf-8", "replace")
        except Exception as exc:  # pragma: no cover
            return f"<cannot read log: {exc!r}>"

    def stop(self) -> str:
        if self._proc.poll() is None:
            try:
                os.killpg(os.getpgid(self._proc.pid), signal.SIGTERM)
                for _ in range(20):
                    time.sleep(0.5)
                    if self._proc.poll() is not None:
                        break
                if self._proc.poll() is None:
                    os.killpg(os.getpgid(self._proc.pid), signal.SIGKILL)
            except ProcessLookupError:  # pragma: no cover
                pass
        return f"stopped (returncode={self._proc.poll()})"


def launch_all(
    topology: Topology,
    *,
    model_path: str = DEFAULT_MODEL_PATH,
    attention_backend: str = "flashinfer",
    page_size: int = 1,
    mem_fraction_static: float = 0.75,
    max_running_requests: int = 256,
    chunked_prefill_size: int = 4096,
    log_dir: str = LOG_DIR,
    extra_args: Optional[List[str]] = None,
    truncate_logs: bool = True,
) -> Dict[str, object]:
    """Start (or restart) one detached SGLang actor per worker node."""

    refs: Dict[str, object] = {}
    for worker in topology.workers:
        name = f"hw3-sglang-{worker.gpu}"
        # replace a previous actor with the same name
        try:
            old = ray.get_actor(name)
            old.stop.remote()
            ray.kill(old, no_restart=True)
            time.sleep(1.0)
        except Exception:
            pass

        args = sglang_server_args(
            model_path,
            port=worker.sglang_port,
            attention_backend=attention_backend,
            page_size=page_size,
            mem_fraction_static=mem_fraction_static,
            max_running_requests=max_running_requests,
            chunked_prefill_size=chunked_prefill_size,
            extra=extra_args,
        )
        log_path = os.path.join(log_dir, f"sglang-gpu{worker.gpu}.log")
        if truncate_logs:
            Path(log_path).write_bytes(b"")
        spec = json.dumps(
            {
                "gpu": worker.gpu,
                "port": worker.sglang_port,
                "args": args,
                "log_path": log_path,
            }
        )
        handle = SglangServerActor.options(
            name=name,
            lifetime="detached",
            runtime_env={"env_vars": {"CUDA_VISIBLE_DEVICES": str(worker.gpu)}},
            resources={worker.pin: 0.001},
        ).remote(spec)
        refs[worker.backend] = handle
    return refs


def get_actors(topology: Topology) -> Dict[str, object]:
    """Re-attach to the detached SGLang actors by name."""

    actors: Dict[str, object] = {}
    for worker in topology.workers:
        try:
            actors[worker.backend] = ray.get_actor(f"hw3-sglang-{worker.gpu}")
        except Exception:
            continue
    return actors


def stop_all(topology: Topology) -> Dict[str, str]:
    results: Dict[str, str] = {}
    for backend, actor in get_actors(topology).items():
        try:
            results[backend] = ray.get(actor.stop.remote(), timeout=120)
        except Exception as exc:
            results[backend] = f"error: {exc!r}"
    return results


async def wait_healthy(
    topology: Topology,
    *,
    timeout_s: float = 1200.0,
    poll_s: float = 3.0,
) -> Dict[str, bool]:
    """Poll ``/health`` on every backend until all four are ready."""

    pending = {w.backend: w.sglang_url for w in topology.workers}
    ready: Dict[str, bool] = {name: False for name in pending}
    deadline = time.time() + timeout_s
    connector = aiohttp.TCPConnector(limit=8, force_close=True)
    async with aiohttp.ClientSession(
        connector=connector, timeout=aiohttp.ClientTimeout(total=5)
    ) as session:
        while time.time() < deadline:
            for name, url in list(pending.items()):
                try:
                    async with session.get(f"{url}/health") as resp:
                        if resp.status == 200:
                            ready[name] = True
                            pending.pop(name, None)
                except Exception:
                    pass
            if not pending:
                break
            await asyncio.sleep(poll_s)
    return ready


async def flush_caches(topology: Topology, *, retries: int = 3) -> Dict[str, dict]:
    """POST ``/flush_cache`` on every backend and verify all four succeed."""

    results: Dict[str, dict] = {}
    connector = aiohttp.TCPConnector(limit=8, force_close=True)
    async with aiohttp.ClientSession(
        connector=connector, timeout=aiohttp.ClientTimeout(total=120)
    ) as session:
        for worker in topology.workers:
            url = f"{worker.sglang_url}/flush_cache"
            for attempt in range(1, retries + 1):
                try:
                    async with session.post(url) as resp:
                        body = await resp.text()
                        results[worker.backend] = {
                            "ok": resp.status == 200,
                            "attempt": attempt,
                            "status": resp.status,
                            "response": body[:200],
                        }
                        if resp.status == 200:
                            break
                except Exception as exc:  # pragma: no cover - network flake
                    results[worker.backend] = {
                        "ok": False,
                        "attempt": attempt,
                        "error": repr(exc),
                    }
                await asyncio.sleep(1.0)
    return results


def server_info(topology: Topology) -> Dict[str, dict]:
    return {
        w.backend: {
            "node_ip": w.node_ip,
            "node_id": w.node_id,
            "gpu": w.gpu,
            "port": w.sglang_port,
            "url": w.sglang_url,
            "log": f"{LOG_DIR}/sglang-gpu{w.gpu}.log",
        }
        for w in topology.workers
    }
