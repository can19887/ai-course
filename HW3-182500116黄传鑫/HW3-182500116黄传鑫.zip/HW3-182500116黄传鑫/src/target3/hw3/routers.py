"""Custom Ray Serve request routers used by group D.

``PrefixAffinityRouter`` is the improved router of group D.  It only uses the
current request and the currently visible service state:

* the prefix family of the request (``x-session-id`` header, which the workload
  generator sets to the prefix family id),
* the per-replica request queue length that Ray Serve keeps in the router cache,
* the router's own in-flight counter per replica (kept accurate through the
  ``on_request_routed`` / ``on_request_completed`` lifecycle hooks),
* each replica's ``max_ongoing_requests`` backpressure limit.

Selection rule
--------------
1. *Affinity*: a deterministic rendezvous hash of the prefix family over the
   replica ids gives a stable ``home`` replica per family.  All requests of one
   family therefore reuse the same SGLang radix cache.
2. *Load guard*: if the home replica is already at (or above)
   ``admission_ratio * max_ongoing_requests`` ongoing requests, the request is
   sent to the least loaded replica instead.
3. *Strict fallback*: when every replica is saturated the router returns the
   ranked list home -> others and lets Ray Serve retry with backoff, so a
   request is never dropped.
"""

from __future__ import annotations

import hashlib
import logging
from typing import Any, Dict, List, Optional

from ray.serve._private.common import ReplicaID
from ray.serve._private.request_router.common import PendingRequest
from ray.serve._private.request_router.replica_wrapper import RunningReplica
from ray.serve._private.request_router.request_router import (
    FIFOMixin,
    RequestRouter,
)

logger = logging.getLogger("ray.serve")


def rendezvous_score(family: str, replica_key: str, salt: str = "hw3") -> int:
    """Deterministic per-(family, replica) score: highest score wins."""

    payload = f"{salt}:{family}:{replica_key}".encode("utf-8")
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "big")


class PrefixAffinityRouter(FIFOMixin, RequestRouter):
    """Prefix-affinity routing with a load guard (group D)."""

    def __init__(
        self,
        *args,
        admission_ratio: float = 0.7,
        salt: str = "hw3",
        **kwargs,
    ) -> None:
        super().__init__(*args, **kwargs)
        self._admission_ratio = float(admission_ratio)
        self._salt = salt
        # In-flight requests per replica, maintained through the lifecycle hooks.
        self._inflight: Dict[str, int] = {}
        # internal_request_id -> replica_id, needed to release the counter.
        self._request_owner: Dict[str, str] = {}
        # Bookkeeping for the report: how often the guard had to intervene.
        self._decisions: Dict[str, int] = {"home": 0, "spill": 0, "no_session": 0}

    # ------------------------------------------------------------------ utils
    def _family(self, pending_request: Optional[PendingRequest]) -> str:
        if pending_request is None:
            return ""
        metadata = pending_request.metadata
        return str(getattr(metadata, "session_id", "") or "")

    def _score(self, family: str, replica: RunningReplica) -> int:
        return rendezvous_score(family, replica.replica_id.to_full_id_str(), self._salt)

    def _queue_len(self, replica: RunningReplica) -> Optional[int]:
        return self._replica_queue_len_cache.get(replica.replica_id)

    def _pressure(self, replica: RunningReplica) -> float:
        """Combined pressure signal: router-local in-flight + measured queue."""

        key = replica.replica_id.to_full_id_str()
        inflight = float(self._inflight.get(key, 0))
        queue_len = self._queue_len(replica)
        if queue_len is None:
            return inflight
        return max(inflight, float(queue_len))

    def _is_home_available(self, replica: RunningReplica) -> bool:
        limit = max(1.0, self._admission_ratio * float(replica.max_ongoing_requests))
        return self._pressure(replica) < limit

    def _least_loaded(self, replicas: List[RunningReplica]) -> List[RunningReplica]:
        def key(replica: RunningReplica):
            return (
                self._pressure(replica),
                replica.replica_id.to_full_id_str(),
            )

        return sorted(replicas, key=key)

    # ------------------------------------------------------------ core policy
    async def choose_replicas(
        self,
        candidate_replicas: List[RunningReplica],
        pending_request: Optional[PendingRequest] = None,
    ) -> List[List[RunningReplica]]:
        if not candidate_replicas:
            return []

        family = self._family(pending_request)
        if not family:
            self._decisions["no_session"] += 1
            return [self._least_loaded(candidate_replicas)]

        ranked = sorted(
            candidate_replicas,
            key=lambda r: (-self._score(family, r), r.replica_id.to_full_id_str()),
        )
        home = ranked[0]
        others = ranked[1:]

        if self._is_home_available(home):
            self._decisions["home"] += 1
            return [[home], others]

        self._decisions["spill"] += 1
        return [self._least_loaded(others), [home]]

    # -------------------------------------------------------------- reporting
    def on_request_routed(
        self,
        pending_request: PendingRequest,
        replica_id: ReplicaID,
        result: Any = None,
    ) -> None:
        key = replica_id.to_full_id_str()
        self._inflight[key] = self._inflight.get(key, 0) + 1
        internal_id = getattr(pending_request.metadata, "internal_request_id", None)
        if internal_id:
            self._request_owner[internal_id] = key

    def on_request_completed(
        self,
        replica_id: ReplicaID,
        internal_request_id: str,
    ) -> None:
        key = self._request_owner.pop(internal_request_id, None)
        if key is None:
            key = replica_id.to_full_id_str()
        remaining = self._inflight.get(key, 0) - 1
        if remaining <= 0:
            self._inflight.pop(key, None)
        else:
            self._inflight[key] = remaining

    def debug_stats(self) -> Dict[str, int]:
        stats = dict(self._decisions)
        stats.update({f"inflight:{k}": v for k, v in self._inflight.items()})
        return stats
