"""Routing policies for groups A-D, expressed as Ray Serve configurations."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass
class PolicySpec:
    """One experiment configuration."""

    name: str
    group: str  # A | B1 | B2 | C | D
    router_name: str  # recorded by the workload generator
    max_ongoing_requests: int
    request_router_class: Any = None
    request_router_kwargs: Dict[str, Any] = field(default_factory=dict)
    description: str = ""
    routing_stats_period_s: float = 10.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "group": self.group,
            "router_name": self.router_name,
            "max_ongoing_requests": self.max_ongoing_requests,
            "request_router_class": (
                None
                if self.request_router_class is None
                else getattr(
                    self.request_router_class, "__name__", str(self.request_router_class)
                )
            ),
            "request_router_kwargs": self.request_router_kwargs,
            "description": self.description,
        }


def default_router_config() -> Dict[str, Any]:
    """Ray Serve's stock request router (power of two choices)."""

    return {}


def consistent_hash_router_config(
    *, session_header_key: str = "x-session-id"
) -> Dict[str, Any]:
    """Built-in ConsistentHashRouter with strict affinity (no fallback)."""

    router_cls = "ray.serve.experimental.consistent_hash_router:ConsistentHashRouter"
    return {
        "request_router_class": router_cls,
        "request_router_kwargs": {
            "num_virtual_nodes": 100,
            "num_fallback_replicas": 0,
        },
    }


def build_policies(b_max_ongoing_requests: int = 64) -> Dict[str, PolicySpec]:
    """The configurations compared in the report.

    ``b_max_ongoing_requests`` is the value selected by group B and is reused
    by groups C and D so that only the routing policy differs between them.
    """

    from .routers import PrefixAffinityRouter

    return {
        "A_default": PolicySpec(
            name="A_default",
            group="A",
            router_name="p2c",
            max_ongoing_requests=5,
            request_router_class=None,
            description="Ray Serve default router (power of two choices), max_ongoing_requests=5",
        ),
        "B1_candidate": PolicySpec(
            name="B1_candidate",
            group="B1",
            router_name="p2c",
            max_ongoing_requests=16,
            request_router_class=None,
            description="Default router with max_ongoing_requests=16",
        ),
        "B2_candidate": PolicySpec(
            name="B2_candidate",
            group="B2",
            router_name="p2c",
            max_ongoing_requests=64,
            request_router_class=None,
            description="Default router with max_ongoing_requests=64",
        ),
        "B3_calibration": PolicySpec(
            name="B3_calibration",
            group="B3",
            router_name="p2c",
            max_ongoing_requests=128,
            request_router_class=None,
            description=(
                "Default router with max_ongoing_requests=128; extra calibration "
                "point used to locate the throughput plateau"
            ),
        ),
        "C_affinity": PolicySpec(
            name="C_affinity",
            group="C",
            router_name="consistent_hash",
            max_ongoing_requests=b_max_ongoing_requests,
            request_router_class=(
                "ray.serve.experimental.consistent_hash_router:ConsistentHashRouter"
            ),
            request_router_kwargs={"num_virtual_nodes": 100, "num_fallback_replicas": 0},
            description="Built-in ConsistentHashRouter on X-Session-Id, num_fallback_replicas=0",
        ),
        "D_improved": PolicySpec(
            name="D_improved",
            group="D",
            router_name="prefix_affinity_guarded",
            max_ongoing_requests=b_max_ongoing_requests,
            request_router_class=PrefixAffinityRouter,
            request_router_kwargs={"admission_ratio": 0.3, "salt": "hw3"},
            description=(
                "Custom PrefixAffinityRouter: rendezvous-hash home replica per prefix "
                "family, spill to the least loaded replica when the home replica "
                "exceeds 30% of max_ongoing_requests"
            ),
        ),
        "D_relaxed": PolicySpec(
            name="D_relaxed",
            group="D1",
            router_name="prefix_affinity_relaxed",
            max_ongoing_requests=b_max_ongoing_requests,
            request_router_class=PrefixAffinityRouter,
            request_router_kwargs={"admission_ratio": 0.7, "salt": "hw3"},
            description=(
                "Same custom router with a looser guard (spill above 70% of "
                "max_ongoing_requests), used for the D parameter study"
            ),
        ),
        "D_tight": PolicySpec(
            name="D_tight",
            group="D2",
            router_name="prefix_affinity_strict",
            max_ongoing_requests=b_max_ongoing_requests,
            request_router_class=PrefixAffinityRouter,
            request_router_kwargs={"admission_ratio": 0.3, "salt": "hw3"},
            description=(
                "Same custom router with a tighter guard: spill only above 30% of "
                "max_ongoing_requests, used to quantify the affinity/skew trade off"
            ),
        ),
    }
