#!/usr/bin/env python3
"""Run one experiment group end to end: deploy -> flush -> replay -> verify.

Called by ``scripts/run_group.sh``.  Everything that touches Ray happens in this
single process:

1. connect to the logical cluster and stop any previous Ray Serve application
2. deploy ``RayServeHTTP`` with the policy configuration of the group
3. check that the four replicas map onto four nodes and four SGLang backends
4. flush all four SGLang radix caches
5. start a GPU sampler thread
6. replay the fixed workload through the Ray Serve HTTP entry point
7. verify the acceptance criteria and write ``run_meta.json``
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

os.environ.setdefault("RAY_SERVE_DISABLE_PLACEMENT_GROUP", "1")
os.environ.setdefault("RAY_SERVE_SESSION_ID_HEADER_KEY", "x-session-id")

sys.path.insert(0, "/root/hw3/src")

import ray  # noqa: E402
from ray import serve  # noqa: E402

from hw3 import sglang_launcher  # noqa: E402
from hw3.cluster import create_placement_group  # noqa: E402
from hw3.policies import build_policies  # noqa: E402
from hw3.run_experiment import (  # noqa: E402
    RESULTS_DIR,
    RUN_DIR,
    TOPOLOGY_PATH,
    WORKLOAD_DIR,
    WORKLOAD_FILE,
    WORKLOAD_SHA256,
    gpu_stats,
    load_topology,
    ray_nodes_summary,
    run_replay,
    stamp_served_model,
    verify_replica_map,
    verify_result,
)
from hw3.serve_app import build_app  # noqa: E402


class GpuSampler:
    """Poll ``nvidia-smi`` in a background thread during a replay."""

    def __init__(self, interval_s: float = 2.0, raw_path: Optional[Path] = None) -> None:
        self.interval_s = interval_s
        self.raw_path = Path(raw_path) if raw_path else (RUN_DIR / "gpu_samples.jsonl")
        self.samples: List[Dict[str, Any]] = []
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def _run(self) -> None:
        while not self._stop.is_set():
            rows = gpu_stats()
            if rows:
                self.samples.append({"t": time.time(), "rows": rows})
            self._stop.wait(self.interval_s)

    def start(self) -> None:
        self._thread.start()

    def stop(self) -> Dict[str, Any]:
        self._stop.set()
        self._thread.join(timeout=10)
        util: List[float] = []
        mem: List[float] = []
        for sample in self.samples:
            for row in sample["rows"]:
                parts = [p.strip() for p in row.split(",")]
                if len(parts) >= 4:
                    try:
                        util.append(float(parts[1].rstrip(" %")))
                        mem.append(float(parts[2].split()[0]))
                    except ValueError:
                        continue
        summary: Dict[str, Any] = {
            "samples": len(self.samples),
            "gpu_util_mean": (sum(util) / len(util)) if util else None,
            "gpu_util_max": max(util) if util else None,
            "gpu_mem_used_mean_mib": (sum(mem) / len(mem)) if mem else None,
        }
        self.raw_path.parent.mkdir(parents=True, exist_ok=True)
        with self.raw_path.open("w", encoding="utf-8") as handle:
            for sample in self.samples:
                handle.write(json.dumps(sample) + "\n")
        summary["raw_file"] = str(self.raw_path)
        return summary


def wait_for_serve_ready(timeout_s: float = 300.0) -> Dict[str, Any]:
    """Poll ``http://127.0.0.1:8000/health`` until the proxy answers."""

    import aiohttp

    deadline = time.time() + timeout_s
    last: Dict[str, Any] = {}
    while time.time() < deadline:
        try:
            async def probe() -> Dict[str, Any]:
                async with aiohttp.ClientSession(
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as session:
                    async with session.get("http://127.0.0.1:8000/health") as resp:
                        return {"status": resp.status, "body": await resp.json()}

            last = asyncio.run(probe())
            if last.get("status") == 200:
                return last
        except Exception as exc:
            last = {"error": repr(exc)}
        time.sleep(3.0)
    return last


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--policy", required=True)
    parser.add_argument("--run-name", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--topology", default=str(TOPOLOGY_PATH))
    parser.add_argument("--base-url", default="http://127.0.0.1:8000")
    parser.add_argument("--model-label", default=sglang_launcher.DEFAULT_MODEL_LABEL)
    parser.add_argument("--model-path", default=sglang_launcher.DEFAULT_MODEL_PATH)
    parser.add_argument("--metadata", action="append", default=[])
    parser.add_argument("--keep-old-results", action="store_true")
    parser.add_argument("--max-deploy-attempts", type=int, default=6)
    args = parser.parse_args(argv)

    policies = build_policies()
    if args.policy not in policies:
        raise SystemExit(f"unknown policy {args.policy}")
    policy = policies[args.policy]

    output_dir = Path(args.output_dir)
    if not output_dir.is_absolute():
        output_dir = (Path("/root/hw3") / output_dir).resolve()
    if output_dir.exists():
        if args.keep_old_results:
            raise SystemExit(f"{output_dir} exists; refusing to overwrite")
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    ray.init(address="auto", ignore_reinit_error=True, log_to_driver=False)
    topology = load_topology(Path(args.topology))

    # 1. stop the previous Serve application
    try:
        serve.shutdown()
        time.sleep(5)
    except Exception as exc:
        print("[run] serve.shutdown:", repr(exc), flush=True)

    # 2. placement group + deployment.  Ray Serve's spreading is best effort,
    #    so redeploy (and stop the old replicas) until the four replicas really
    #    sit on four different worker nodes with four different backends.
    attempts = []
    mapping: Dict[str, Any] = {}
    ready: Dict[str, Any] = {}
    ok = False
    for attempt in range(1, args.max_deploy_attempts + 1):
        try:
            create_placement_group(topology)
        except Exception as exc:
            print("[run] placement group:", repr(exc), flush=True)

        app = build_app(
            max_ongoing_requests=policy.max_ongoing_requests,
            request_router_class=policy.request_router_class,
            request_router_kwargs=policy.request_router_kwargs,
        )
        serve.run(app, name="hw3", route_prefix="/")
        print(
            f"[run] attempt {attempt}: serve app deployed "
            + json.dumps(policy.to_dict(), ensure_ascii=False),
            flush=True,
        )
        ready = wait_for_serve_ready()
        mapping = asyncio.run(verify_replica_map())
        attempts.append(
            {
                "attempt": attempt,
                "replicas": mapping.get("replicas", {}),
                "distinct_nodes": mapping.get("distinct_nodes", []),
                "distinct_backends": mapping.get("distinct_backends", []),
                "ok": mapping.get("four_replicas_four_backends_four_nodes", False),
            }
        )
        print(
            f"[run] attempt {attempt}: nodes={len(mapping.get('distinct_nodes', []))} "
            f"backends={len(mapping.get('distinct_backends', []))} "
            f"ok={mapping.get('four_replicas_four_backends_four_nodes')}",
            flush=True,
        )
        if mapping.get("four_replicas_four_backends_four_nodes"):
            ok = True
            break
        serve.shutdown()
        time.sleep(8)

    # 3. flush the four caches
    flush = asyncio.run(sglang_launcher.flush_caches(topology))
    nodes = ray_nodes_summary()
    deploy_report = {
        "policy": policy.to_dict(),
        "health": ready,
        "replica_map": mapping,
        "deploy_attempts": attempts,
        "flush_cache": flush,
        "ray_nodes": nodes,
        "gpu_stats_before": gpu_stats(),
    }
    (output_dir / "deploy.json").write_text(
        json.dumps(deploy_report, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(deploy_report, indent=2, ensure_ascii=False), flush=True)

    flush_ok = all(v.get("ok") for v in flush.values())
    if not (ok and flush_ok):
        print("[run] ERROR: replica map or cache flush invalid", flush=True)
        return 2

    # 4. replay with GPU sampling.  The backend startup command line is recorded
    #    both in metadata and in the run's own json files, so the SGLang
    #    configuration is provable from the artifacts alone.
    sglang_command = ""
    gpu0_log = Path("/root/hw3/logs/sglang-gpu0.log")
    if gpu0_log.exists():
        first = gpu0_log.read_text(encoding="utf-8", errors="replace").splitlines()[0]
        sglang_command = first[4:].strip() if first.startswith("CMD ") else first.strip()

    metadata = [
        f"policy_group={policy.group}",
        f"policy_name={policy.name}",
        f"policy_description={policy.description}",
        f"router_name={policy.router_name}",
        f"max_ongoing_requests={policy.max_ongoing_requests}",
        f"request_router_kwargs={json.dumps(policy.request_router_kwargs, ensure_ascii=False)}",
        f"request_router_class={policy.to_dict()['request_router_class']}",
        f"model={args.model_label}",
        f"served_model_path={args.model_path}",
        f"sglang_command={sglang_command}",
        "replicas=4",
        "gpu=NVIDIA-RTX-4090-x4",
        "serve=ray-2.59.0",
        "placement_group=hw3-replicas-SPREAD-4-bundles",
        f"ray_nodes={nodes['total']}",
    ] + list(args.metadata)

    sampler = GpuSampler(
        interval_s=2.0, raw_path=RUN_DIR / f"gpu_samples_{args.run_name}.jsonl"
    )
    sampler.start()
    started = time.time()
    rc = run_replay(
        policy,
        run_name=args.run_name,
        output_dir=output_dir,
        base_url=args.base_url,
        overwrite=True,
        metadata=metadata,
        model=args.model_label,
    )
    elapsed = time.time() - started
    gpu_summary = sampler.stop()
    # keep the raw samples with the run itself
    if Path(gpu_summary["raw_file"]).exists():
        shutil.copy2(gpu_summary["raw_file"], output_dir / "gpu_samples.jsonl")
        gpu_summary["raw_file"] = str(output_dir / "gpu_samples.jsonl")

    # the generator cannot record the real model, so stamp it into its artifacts
    model_stamp = stamp_served_model(
        output_dir, args.model_label, sglang_command
    )

    # 5. verify
    verification = verify_result(output_dir)
    meta = {
        "policy": policy.to_dict(),
        "run_name": args.run_name,
        "output_dir": str(output_dir),
        "replay_seconds": elapsed,
        "replay_exit_code": rc,
        "gpu_summary": gpu_summary,
        "gpu_stats_after": gpu_stats(),
        "replica_map": mapping,
        "ray_nodes": nodes,
        "flush_cache_ok": flush_ok,
        "model_stamp": model_stamp,
        "sglang_command": sglang_command,
        "verification": {k: v for k, v in verification.items() if k != "summary"},
    }
    (output_dir / "run_meta.json").write_text(
        json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(meta, indent=2, ensure_ascii=False), flush=True)

    if not verification["ok"]:
        print("[run] ERROR: acceptance criteria not met", flush=True)
        return 3
    if rc != 0:
        print(f"[run] ERROR: workload generator exit code {rc}", flush=True)
        return rc
    print("[run] OK", args.run_name, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
