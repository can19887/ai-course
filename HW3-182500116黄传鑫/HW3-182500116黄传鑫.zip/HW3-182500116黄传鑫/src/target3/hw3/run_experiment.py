"""Command line driver for the four-replica Ray Serve / SGLang experiments.

Subcommands
-----------
``env``          print GPU / driver / ray / sglang versions as JSON
``serve-up``     start the Ray Serve app for one policy group
``serve-down``   stop the Ray Serve app and flush all SGLang caches
``deploy``       deploy a policy group, verify routing headers, flush caches
``replay``       run the fixed workload against the running Ray Serve app
``run``          deploy + replay + verify in one shot
``verify``       check one result directory against the acceptance criteria
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

os.environ.setdefault("RAY_SERVE_DISABLE_PLACEMENT_GROUP", "1")
os.environ.setdefault("RAY_SERVE_SESSION_ID_HEADER_KEY", "x-session-id")

import ray  # noqa: E402
from ray import serve  # noqa: E402

from . import sglang_launcher  # noqa: E402
from .cluster import Topology, create_placement_group  # noqa: E402
from .policies import PolicySpec, build_policies  # noqa: E402

WORKLOAD_DIR = "/root/hw3/26fall-HW-data/workloads/hw2/target3-routing-policies"
WORKLOAD_FILE = f"{WORKLOAD_DIR}/mooncake_prefix_workload_v2_seed2026.jsonl"
WORKLOAD_SHA256 = "f154ba954e28ca9612257edf5deb0d5dfc6bf27fd0115a701e1f49e52df75b03"
RUN_DIR = Path("/root/hw3/run")
RESULTS_DIR = Path("/root/hw3/results")
TOPOLOGY_PATH = RUN_DIR / "topology.json"


# --------------------------------------------------------------------- helpers
def load_topology(path: Path = TOPOLOGY_PATH) -> Topology:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    from .cluster import NodeInfo

    topology = Topology(
        created_at=data["created_at"],
        ray_version=data["ray_version"],
        placement_group_name=data.get("placement_group_name", "hw3-replicas"),
    )
    topology.nodes = [NodeInfo(**node) for node in data["nodes"]]
    return topology


def ray_nodes_summary() -> Dict[str, Any]:
    """Live Ray node summary: 1 head + 4 workers must all be alive."""

    nodes = [n for n in ray.nodes() if n.get("Alive")]
    head = [n for n in nodes if n.get("NodeManagerHostname") and n.get("NodeID")]
    summary = {
        "total": len(nodes),
        "head_ip": ray.get_runtime_context().gcs_address.split(":")[0],
        "nodes": [
            {
                "node_id": n["NodeID"],
                "ip": n["NodeManagerAddress"],
                "cpus": n["Resources"].get("CPU"),
                "object_store_memory": n["Resources"].get("object_store_memory"),
            }
            for n in nodes
        ],
    }
    summary["workers"] = len(nodes) - 1
    return summary


def env_info() -> Dict[str, Any]:
    info: Dict[str, Any] = {"timestamp": time.strftime("%Y-%m-%dT%H:%M:%S%z")}
    try:
        import torch

        info["torch"] = torch.__version__
        info["torch_cuda"] = torch.version.cuda
        info["gpu_count"] = torch.cuda.device_count()
        info["gpus"] = [torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())]
    except Exception as exc:  # pragma: no cover
        info["torch_error"] = repr(exc)
    try:
        import sglang

        info["sglang"] = sglang.__version__
    except Exception as exc:  # pragma: no cover
        info["sglang_error"] = repr(exc)
    try:
        info["ray"] = ray.__version__
    except Exception as exc:  # pragma: no cover
        info["ray_error"] = repr(exc)
    try:
        out = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=index,name,driver_version,memory.total",
                "--format=csv,noheader",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        info["nvidia_smi"] = out.stdout.strip().splitlines()
    except Exception as exc:  # pragma: no cover
        info["nvidia_smi_error"] = repr(exc)
    info["python"] = sys.version.split()[0]
    return info


def gpu_stats() -> List[str]:
    try:
        out = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=index,utilization.gpu,memory.used,power.draw",
                "--format=csv,noheader",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        return out.stdout.strip().splitlines()
    except Exception:  # pragma: no cover
        return []


def policy_by_name(name: str) -> PolicySpec:
    policies = build_policies()
    if name not in policies:
        raise SystemExit(f"unknown policy {name}; choose from {sorted(policies)}")
    return policies[name]


# ------------------------------------------------------------------ serve wiring
def _router_for(policy: PolicySpec) -> Any:
    """Resolve the router class/string from the policy definition."""

    if policy.request_router_class is None:
        return None
    return policy.request_router_class


def deploy_policy(policy: PolicySpec, *, router_stats_period_s: float = 10.0) -> None:
    from .serve_app import build_app

    app = build_app(
        max_ongoing_requests=policy.max_ongoing_requests,
        request_router_class=_router_for(policy),
        request_router_kwargs=policy.request_router_kwargs,
        routing_stats_period_s=router_stats_period_s,
    )
    serve.run(app, name="hw3", route_prefix="/")


async def _probe_health(session, url: str) -> Dict[str, Any]:
    try:
        async with session.get(url) as resp:
            return {"status": resp.status, "body": await resp.json()}
    except Exception as exc:
        return {"error": repr(exc)}


async def verify_replica_map(
    driver_ip: str = "127.0.0.1",
    *,
    n: int = 40,
    timeout_s: float = 180.0,
) -> Dict[str, Any]:
    """Probe /health and verify the replica -> backend/node mapping.

    Ray Serve spreads one request over any replica, so a batch of concurrent
    probes is used to observe all four replicas.  Each replica must map to
    exactly one Ray node and one SGLang backend.
    """

    import aiohttp

    url = f"http://{driver_ip}:8000/health"
    seen: Dict[str, Dict[str, Any]] = {}
    deadline = time.time() + timeout_s
    probes = 0
    connector = aiohttp.TCPConnector(limit=64, force_close=True)
    async with aiohttp.ClientSession(
        connector=connector, timeout=aiohttp.ClientTimeout(total=15)
    ) as session:
        while time.time() < deadline and len(seen) < 4:
            results = await asyncio.gather(*[_probe_health(session, url) for _ in range(n)])
            probes += len(results)
            for payload in results:
                body = (payload or {}).get("body") or {}
                if body.get("replica_id"):
                    seen[body["replica_id"]] = body
            if len(seen) < 4:
                await asyncio.sleep(2.0)

    backends: Dict[str, str] = {}
    nodes: Dict[str, str] = {}
    for replica_id, body in seen.items():
        backends.setdefault(body["backend"], replica_id)
        nodes.setdefault(body["node_id"], replica_id)
    mapping_ok = (
        len(backends) == len(seen) and len(nodes) == len(seen) and len(seen) == 4
    )
    return {
        "probes": probes,
        "replicas": seen,
        "distinct_backends": sorted(backends),
        "distinct_nodes": sorted(nodes),
        "four_replicas_four_backends_four_nodes": mapping_ok,
    }


def flush_and_report(topology: Topology) -> Dict[str, Any]:
    results = asyncio.run(sglang_launcher.flush_caches(topology))
    return results


# ------------------------------------------------------------------- replay
def run_replay(
    policy: PolicySpec,
    *,
    run_name: str,
    output_dir: Path,
    base_url: str = "http://127.0.0.1:8000",
    overwrite: bool = False,
    metadata: Optional[List[str]] = None,
) -> int:
    """Replay the fixed workload through the Ray Serve entry point.

    ``run_workload.py`` has no ``--model`` flag; it always records its own
    built-in default, so :func:`stamp_served_model` is applied afterwards.
    """

    output_dir = Path(output_dir).resolve()
    cmd = [
        sys.executable,
        f"{WORKLOAD_DIR}/run_workload.py",
        "--policy",
        "serve",
        "--run-name",
        run_name,
        "--router-name",
        policy.router_name,
        "--max-ongoing-requests",
        str(policy.max_ongoing_requests),
        "--base-url",
        base_url,
        "--workload",
        WORKLOAD_FILE,
        "--expected-workload-sha256",
        WORKLOAD_SHA256,
        "--max-in-flight",
        "2048",
        "--output-dir",
        str(output_dir),
    ]
    if overwrite:
        cmd.append("--overwrite")
    for item in metadata or []:
        cmd += ["--metadata", item]
    print("[replay]", " ".join(cmd), flush=True)
    return subprocess.call(cmd, cwd=WORKLOAD_DIR)


def stamp_served_model(output_dir: Path, served_model: str, sglang_command: str) -> Dict[str, Any]:
    """Record what SGLang actually served in the generator's own artifacts.

    ``run_workload.py`` writes its own ``--model`` default (``Qwen/Qwen3-0.6B``)
    into ``config.json``/``summary.json`` and has no CLI flag to override it, so
    the true model would otherwise never appear next to the measurements.  The
    original value is preserved in ``model_recorded_by_generator``.
    """

    result: Dict[str, Any] = {}
    for name in ("config.json", "summary.json"):
        path = Path(output_dir) / name
        if not path.exists():
            result[name] = "missing"
            continue
        data = json.loads(path.read_text(encoding="utf-8"))
        original = data.get("model")
        data["model"] = served_model
        data["model_recorded_by_generator"] = original
        data["model_note"] = (
            "run_workload.py has no --model flag and always records its built-in "
            "default; the value below is the model SGLang actually served "
            "(see sglang_command / metadata.model)"
        )
        data["sglang_command"] = sglang_command
        path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
        )
        result[name] = {"before": original, "after": served_model}
    return result
    if overwrite:
        cmd.append("--overwrite")
    for item in metadata or []:
        cmd += ["--metadata", item]
    print("[replay]", " ".join(cmd), flush=True)
    return subprocess.call(cmd, cwd=WORKLOAD_DIR)


def verify_result(output_dir: Path) -> Dict[str, Any]:
    summary_path = Path(output_dir) / "summary.json"
    if not summary_path.exists():
        return {"ok": False, "reason": "summary.json missing"}
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    checks = {
        "successful_2048": summary["successful"] == 2048,
        "failed_0": summary["failed"] == 0,
        "incomplete_0": summary["incomplete"] == 0,
        "warmup_ok": summary["warmup_successful"] == 64
        and summary["warmup_failed"] == 0
        and summary["warmup_incomplete"] == 0,
        "validation_errors_empty": summary["validation_errors"] == [],
        "four_replicas": len(summary["replica_distribution"]) == 4,
        "four_nodes": len(summary["node_distribution"]) == 4,
        "four_backends": len(summary["backend_distribution"]) == 4,
    }
    return {
        "ok": all(checks.values()),
        "checks": checks,
        "summary": summary,
    }


# ---------------------------------------------------------------------- main
def cmd_env(args: argparse.Namespace) -> int:
    print(json.dumps(env_info(), indent=2, ensure_ascii=False))
    return 0


def cmd_deploy(args: argparse.Namespace) -> int:
    os.environ["HW3_TOPOLOGY"] = str(args.topology)
    ray.init(address=args.ray_address or "auto", ignore_reinit_error=True)
    topology = load_topology(Path(args.topology))
    policy = policy_by_name(args.policy)

    if not args.skip_placement_group:
        try:
            create_placement_group(topology)
        except Exception as exc:  # pragma: no cover
            print("[warn] placement group:", repr(exc), flush=True)

    deploy_policy(policy, router_stats_period_s=args.routing_stats_period_s)
    mapping = asyncio.run(verify_replica_map())
    flush = flush_and_report(topology)
    report = {
        "policy": policy.to_dict(),
        "ray_nodes": ray_nodes_summary(),
        "replica_map": mapping,
        "flush_cache": flush,
    }
    Path(args.report).parent.mkdir(parents=True, exist_ok=True)
    Path(args.report).write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(report, indent=2, ensure_ascii=False))
    ok = mapping["four_replicas_four_backends_four_nodes"] and all(
        v.get("ok") for v in flush.values()
    )
    return 0 if ok else 2


def cmd_serve_down(args: argparse.Namespace) -> int:
    ray.init(address=args.ray_address or "auto", ignore_reinit_error=True)
    serve.shutdown()
    topology = load_topology(Path(args.topology))
    flush = flush_and_report(topology)
    print(json.dumps({"serve": "down", "flush_cache": flush}, indent=2, ensure_ascii=False))
    return 0 if all(v.get("ok") for v in flush.values()) else 2


def cmd_run(args: argparse.Namespace) -> int:
    """Deploy the policy, replay the workload, verify the result."""

    output_dir = Path(args.output_dir)
    if output_dir.exists() and any(output_dir.glob("*.json")):
        if not args.overwrite:
            raise SystemExit(f"{output_dir} already has results; pass --overwrite")
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    os.environ["HW3_TOPOLOGY"] = str(args.topology)
    ray.init(address=args.ray_address or "auto", ignore_reinit_error=True)
    topology = load_topology(Path(args.topology))
    policy = policy_by_name(args.policy)

    deploy_report_path = output_dir / "deploy.json"
    gpu_before = gpu_stats()
    deploy_argv = [
        "--policy",
        args.policy,
        "--topology",
        str(args.topology),
        "--report",
        str(deploy_report_path),
    ]
    if args.no_placement_group:
        deploy_argv.append("--skip-placement-group")
    # Deploy in-process (same process already connected to Ray).
    deploy_args = build_arg_parser().parse_args(["deploy", *deploy_argv])
    code = cmd_deploy(deploy_args)
    if code != 0:
        print(f"[error] deploy failed with code {code}", flush=True)
        return code

    metadata = [
        f"policy_group={policy.group}",
        f"policy_name={policy.name}",
        f"policy_description={policy.description}",
        f"router_class={deploy_args.policy}",
        f"max_ongoing_requests={policy.max_ongoing_requests}",
        f"request_router_kwargs={json.dumps(policy.request_router_kwargs)}",
        f"model={args.model_label}",
        f"replicas=4",
        f"gpu=nvidia-rtx-4090-x4",
        "serve_placement_group=hw3-replicas(SPREAD,1-bundle-per-worker-node)",
    ] + list(args.metadata or [])

    t0 = time.time()
    rc = run_replay(
        policy,
        run_name=args.run_name,
        output_dir=output_dir,
        base_url=args.base_url,
        overwrite=True,
        metadata=metadata,
    )
    elapsed = time.time() - t0

    verification = verify_result(output_dir)
    gpu_after = gpu_stats()
    meta = {
        "policy": policy.to_dict(),
        "run_name": args.run_name,
        "replay_seconds": elapsed,
        "replay_exit_code": rc,
        "gpu_stats_before": gpu_before,
        "gpu_stats_after": gpu_after,
        "verification": {k: v for k, v in verification.items() if k != "summary"},
    }
    (output_dir / "run_meta.json").write_text(
        json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(meta, indent=2, ensure_ascii=False))
    if not verification["ok"]:
        print("[error] result did not satisfy acceptance criteria", flush=True)
        return 3
    if rc != 0:
        print(f"[error] workload generator exit code {rc}", flush=True)
        return rc
    return 0


def cmd_verify(args: argparse.Namespace) -> int:
    report = verify_result(Path(args.output_dir))
    print(json.dumps({k: v for k, v in report.items() if k != "summary"}, indent=2))
    summary = report.get("summary") or {}
    keys = [
        "successful",
        "failed",
        "incomplete",
        "throughput_rps",
        "cache_hit_rate",
        "prompt_tokens_total",
        "cached_tokens_total",
        "computed_prefill_tokens_total",
        "ttft_s",
        "latency_s",
        "replica_distribution",
        "backend_distribution",
        "node_distribution",
    ]
    print(json.dumps({k: summary.get(k) for k in keys}, indent=2, ensure_ascii=False))
    return 0 if report["ok"] else 3


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    p_env = sub.add_parser("env")
    p_env.set_defaults(func=cmd_env)

    common = dict(
        topology=str(TOPOLOGY_PATH),
        ray_address="auto",
        policy="A_default",
    )

    p_deploy = sub.add_parser("deploy")
    p_deploy.add_argument("--policy", default=common["policy"])
    p_deploy.add_argument("--topology", default=common["topology"])
    p_deploy.add_argument("--ray-address", default=common["ray_address"])
    p_deploy.add_argument("--report", default=str(RUN_DIR / "deploy.json"))
    p_deploy.add_argument("--routing-stats-period-s", type=float, default=10.0)
    p_deploy.add_argument("--skip-placement-group", action="store_true")
    p_deploy.set_defaults(func=cmd_deploy)

    p_down = sub.add_parser("serve-down")
    p_down.add_argument("--topology", default=common["topology"])
    p_down.add_argument("--ray-address", default=common["ray_address"])
    p_down.set_defaults(func=cmd_serve_down)

    p_run = sub.add_parser("run")
    p_run.add_argument("--policy", required=True)
    p_run.add_argument("--run-name", required=True)
    p_run.add_argument("--output-dir", required=True)
    p_run.add_argument("--topology", default=common["topology"])
    p_run.add_argument("--ray-address", default=common["ray_address"])
    p_run.add_argument("--base-url", default="http://127.0.0.1:8000")
    p_run.add_argument("--model-label", default=sglang_launcher.DEFAULT_MODEL_LABEL)
    p_run.add_argument("--metadata", action="append", default=[])
    p_run.add_argument("--overwrite", action="store_true")
    p_run.add_argument("--no-placement-group", action="store_true")
    p_run.set_defaults(func=cmd_run)

    p_verify = sub.add_parser("verify")
    p_verify.add_argument("--output-dir", required=True)
    p_verify.set_defaults(func=cmd_verify)
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_arg_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
