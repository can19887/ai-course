#!/usr/bin/env python3
"""Smoke test after the cluster is up.

Checks, in order:

1. Ray sees exactly one head node plus four worker nodes.
2. All four SGLang backends answer ``/health``.
3. ``/flush_cache`` succeeds on all four.
4. A direct ``/generate`` call returns a complete SSE stream and reports
   ``prompt_tokens``/``cached_tokens`` (the fields the report needs).
5. Repeating the same prompt twice shows a prefix-cache hit on the second call.
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, "/root/hw3/src")

import aiohttp  # noqa: E402
import ray  # noqa: E402

from hw3 import sglang_launcher  # noqa: E402
from hw3.run_experiment import load_topology  # noqa: E402


async def generate(url: str, tokens: list[int], max_new_tokens: int = 8) -> dict:
    payload = {
        "input_ids": tokens,
        "sampling_params": {
            "temperature": 0.0,
            "max_new_tokens": max_new_tokens,
            "min_new_tokens": max_new_tokens,
            "ignore_eos": True,
            "sampling_seed": 2026,
        },
        "stream": True,
    }
    out = {"chunks": 0, "prompt_tokens": None, "cached_tokens": None, "output_ids": 0}
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=120)) as session:
        async with session.post(f"{url}/generate", json=payload) as resp:
            out["status"] = resp.status
            if resp.status != 200:
                out["error"] = (await resp.text())[:300]
                return out
            async for raw in resp.content:
                line = raw.decode("utf-8", "replace").strip()
                if not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if not data or data == "[DONE]":
                    continue
                chunk = json.loads(data)
                meta = chunk.get("meta_info") or {}
                if out["prompt_tokens"] is None and chunk.get("output_ids"):
                    out["prompt_tokens"] = meta.get("prompt_tokens")
                    out["cached_tokens"] = meta.get("cached_tokens")
                if chunk.get("output_ids"):
                    out["chunks"] += 1
                    out["output_ids"] = len(chunk["output_ids"])
    return out


async def main() -> int:
    ray.init(address="auto", ignore_reinit_error=True, log_to_driver=False)
    nodes = [n for n in ray.nodes() if n.get("Alive")]
    topology = load_topology(Path("/root/hw3/run/topology.json"))
    report = {
        "ray_nodes": {
            "total": len(nodes),
            "head": [n["NodeID"] for n in nodes][0],
            "ips": sorted(n["NodeManagerAddress"] for n in nodes),
            "one_head_four_workers": len(nodes) == 5,
        },
        "topology": {
            "workers": [
                {"index": w.index, "gpu": w.gpu, "backend": w.backend, "url": w.sglang_url}
                for w in topology.workers
            ]
        },
    }
    ready = await sglang_launcher.wait_healthy(topology, timeout_s=60, poll_s=2)
    report["health"] = ready
    flush = await sglang_launcher.flush_caches(topology)
    report["flush_cache"] = {k: v.get("ok") for k, v in flush.items()}

    # a 1600-token prompt built the same way the workload generator builds it
    import hashlib

    def block(hash_id: int, size: int = 128) -> list[int]:
        return [
            4096
            + int.from_bytes(
                hashlib.sha256(f"block:2026:{hash_id}:{p}".encode()).digest()[:8], "big"
            )
            % 60000
            for p in range(size)
        ]

    tokens: list[int] = []
    for hash_id in [0, 133799, 133800, 133801, 133802, 133803, 133804, 133805, 133806, 133807, 133808, 133809]:
        tokens.extend(block(hash_id))
    tokens.extend(
        [
            4096
            + int.from_bytes(
                hashlib.sha256(f"suffix:2026:smoke-{p}".encode()).digest()[:8], "big"
            )
            % 60000
            for p in range(64)
        ]
    )
    report["prompt_len"] = len(tokens)

    first = await generate(topology.workers[0].sglang_url, tokens)
    second = await generate(topology.workers[0].sglang_url, tokens)
    report["generate_first"] = first
    report["generate_second"] = second
    report["prefix_cache_observed"] = bool(
        second.get("cached_tokens") and second["cached_tokens"] > 0
    )

    ok = (
        report["ray_nodes"]["one_head_four_workers"]
        and all(ready.values())
        and all(report["flush_cache"].values())
        and first.get("status") == 200
        and first.get("chunks", 0) > 0
        and report["prefix_cache_observed"]
    )
    report["ok"] = ok
    Path("/root/hw3/run/smoke.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0 if ok else 2


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
