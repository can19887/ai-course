#!/usr/bin/env python3
"""Render the figures used in report.pdf from results/*/summary.json + CSV files."""

from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

GROUPS = [
    ("A\np2c/mor=5", "A_default"),
    ("B1\np2c/mor=16", "B_candidates/candidate-1"),
    ("B2\np2c/mor=64", "B_candidates/candidate-2"),
    ("C\nconsistenthash", "C_affinity"),
    ("D\nprefix-affinity", "D_improved"),
]


def load(results: Path):
    rows = []
    for label, rel in GROUPS:
        path = results / rel / "summary.json"
        if not path.exists():
            continue
        summary = json.loads(path.read_text(encoding="utf-8"))
        rows.append((label, summary, results / rel / "requests.csv"))
    return rows


def fig_main(rows, out: Path) -> None:
    labels = [r[0] for r in rows]
    throughput = [r[1]["throughput_rps"] for r in rows]
    cache = [r[1]["cache_hit_rate"] * 100 for r in rows]
    ttft = [r[1]["ttft_s"]["p95"] for r in rows]
    latency = [r[1]["latency_s"]["p95"] for r in rows]

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.2))
    axes[0].bar(labels, throughput, color="#2f6fed")
    axes[0].set_title("Throughput (req/s)")
    axes[1].bar(labels, cache, color="#2fa36b")
    axes[1].set_title("Prefix cache hit rate (%)")
    axes[1].set_ylim(0, 100)
    width = 0.38
    import numpy as np

    x = np.arange(len(labels))
    axes[2].bar(x - width / 2, ttft, width, label="TTFT p95", color="#e08a1e")
    axes[2].bar(x + width / 2, latency, width, label="E2E p95", color="#b8474b")
    axes[2].set_xticks(x)
    axes[2].set_xticklabels(labels)
    axes[2].set_title("Tail latency (s)")
    axes[2].legend()
    fig.tight_layout()
    fig.savefig(out / "fig_main.png", dpi=150)
    plt.close(fig)


def fig_backends(rows, out: Path) -> None:
    fig, axes = plt.subplots(1, len(rows), figsize=(3.1 * len(rows), 3.4), sharey=True)
    if len(rows) == 1:
        axes = [axes]
    for ax, (label, summary, _) in zip(axes, rows):
        dist = summary["backend_distribution"]
        keys = sorted(dist)
        values = [dist[k] for k in keys]
        shares = [v / sum(values) * 100 for v in values]
        ax.bar([k.replace("sglang-", "b") for k in keys], shares, color="#4b6cb7")
        ax.set_title(label.replace("\n", " "), fontsize=9)
        ax.set_ylim(0, 100)
        for index, value in enumerate(shares):
            ax.text(index, value + 1.5, f"{value:.0f}%", ha="center", fontsize=8)
    axes[0].set_ylabel("share of measured requests (%)")
    fig.tight_layout()
    fig.savefig(out / "fig_backends.png", dpi=150)
    plt.close(fig)


def fig_timeline(rows, out: Path) -> None:
    fig, axes = plt.subplots(len(rows), 1, figsize=(11, 1.7 * len(rows)), sharex=True)
    if len(rows) == 1:
        axes = [axes]
    for ax, (label, _, csv_path) in zip(axes, rows):
        if not Path(csv_path).exists():
            continue
        with Path(csv_path).open("r", encoding="utf-8", newline="") as handle:
            records = list(csv.DictReader(handle))
        backends = sorted({r["backend"] for r in records})
        buckets: Dict[int, Counter] = defaultdict(Counter)
        for record in records:
            buckets[int(float(record["actual_send_s"]) // 2)][record["backend"]] += 1
        keys = sorted(buckets)
        bottom = [0] * len(keys)
        for backend in backends:
            values = [buckets[k].get(backend, 0) for k in keys]
            ax.bar(keys, values, bottom=bottom, label=backend, width=0.9)
            bottom = [b + v for b, v in zip(bottom, values)]
        ax.set_ylabel(label.replace("\n", " "), fontsize=8)
        ax.tick_params(labelsize=7)
    axes[0].legend(fontsize=7, ncol=4)
    axes[-1].set_xlabel("time since start of measured phase (2 s buckets)")
    fig.tight_layout()
    fig.savefig(out / "fig_timeline.png", dpi=150)
    plt.close(fig)


def fig_family_heat(rows, out: Path) -> None:
    """Per-family backend concentration for the affinity groups."""

    fig, axes = plt.subplots(1, len(rows), figsize=(3.1 * len(rows), 3.6))
    if len(rows) == 1:
        axes = [axes]
    for ax, (label, _, csv_path) in zip(axes, rows):
        if not Path(csv_path).exists():
            continue
        with Path(csv_path).open("r", encoding="utf-8", newline="") as handle:
            records = list(csv.DictReader(handle))
        families = sorted({r["prefix_family"] for r in records})
        backends = sorted({r["backend"] for r in records})
        index = {b: i for i, b in enumerate(backends)}
        counts = defaultdict(Counter)
        for record in records:
            counts[record["prefix_family"]][record["backend"]] += 1
        positions = []
        colors = []
        for position, family in enumerate(families):
            total = sum(counts[family].values())
            for backend, count in counts[family].items():
                positions.append((position, index[backend], count / total))
        for x, y, share in positions:
            ax.scatter(x, y, s=share * 60, color="#333333", alpha=0.6)
        ax.set_yticks(range(len(backends)))
        ax.set_yticklabels([b.replace("sglang-", "b") for b in backends], fontsize=8)
        ax.set_xlabel("prefix family (sorted)", fontsize=8)
        ax.set_title(label.replace("\n", " "), fontsize=9)
        ax.tick_params(labelsize=7)
    axes[0].set_ylabel("SGLang backend")
    fig.tight_layout()
    fig.savefig(out / "fig_family_backend.png", dpi=150)
    plt.close(fig)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", default="/root/hw3/results")
    parser.add_argument("--out", default="/root/hw3/report/fig")
    args = parser.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    rows = load(Path(args.results))
    if not rows:
        raise SystemExit("no summaries found")
    fig_main(rows, out)
    fig_backends(rows, out)
    fig_timeline(rows, out)
    fig_family_heat(rows, out)
    print("figures written to", out, [p.name for p in sorted(out.glob("*.png"))])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
