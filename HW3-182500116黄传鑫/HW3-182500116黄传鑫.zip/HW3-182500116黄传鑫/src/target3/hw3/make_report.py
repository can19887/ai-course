#!/usr/bin/env python3
"""Render report.md from the measured numbers (report/numbers.json).

Usage::

    python -m hw3.make_report --numbers report/numbers.json --out report/report.md

Every table is filled from the run artifacts, never typed by hand.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List, Optional

GROUP_ORDER = ["A", "B1", "B2", "C", "D"]
GROUP_TITLE = {
    "A": "A（默认路由 p2c, mor=5）",
    "B1": "B1（p2c, mor=16）",
    "B2": "B2（p2c, mor=64）",
    "C": "C（consistenthash, mor=B）",
    "D": "D（前缀亲和+负载保护, mor=B）",
}
TIER_ORDER = ["superhot", "hot", "warm", "cold"]
TIER_TITLE = {
    "superhot": "超热",
    "hot": "热",
    "warm": "中等",
    "cold": "冷",
}


def fmt(value: Optional[float], digits: int = 3) -> str:
    if value is None:
        return "—"
    if isinstance(value, (int,)):
        return str(value)
    return f"{value:.{digits}f}"


def pct(value: Optional[float], digits: int = 1) -> str:
    if value is None:
        return "—"
    return f"{value * 100:.{digits}f}%"


class ReportBuilder:
    def __init__(self, numbers: Dict[str, Any]) -> None:
        self.numbers = numbers
        self.groups: Dict[str, Dict[str, Any]] = numbers.get("groups", {})

    def has(self, group: str) -> bool:
        return group in self.groups

    def g(self, group: str) -> Dict[str, Any]:
        return self.groups[group]

    # ------------------------------------------------------------------ tables
    def table_main(self) -> str:
        header = (
            "| 组别 | 成功率 | 吞吐量<br>(req/s) | 缓存命中率 | 实际 Prefill<br>token 数 | "
            "TTFT p95<br>(s) | E2E p95<br>(s) | 后端0 | 后端1 | 后端2 | 后端3 |"
        )
        rows = [header, "|" + "---|" * 11]
        for group in GROUP_ORDER:
            if not self.has(group):
                continue
            entry = self.g(group)
            summary = entry["summary"]
            backends = entry["backend_requests"]
            success = summary["successful"] / max(1, summary["successful"] + summary["failed"] + summary["incomplete"])
            cells = [
                group,
                pct(success, 2),
                fmt(summary["throughput_rps"], 1),
                pct(entry["cache_hit_rate"], 1),
                f"{entry['computed_prefill_tokens']:,}",
                fmt(entry["ttft_p95"], 3),
                fmt(entry["latency_p95"], 3),
            ]
            for index in range(4):
                key = f"sglang-{index}"
                cells.append(str(backends.get(key, 0)))
            rows.append("| " + " | ".join(cells) + " |")
        return "\n".join(rows)

    def table_backends(self) -> str:
        header = "| 组别 | 后端0 | 后端1 | 后端2 | 后端3 | 最大后端占比 |"
        rows = [header, "|" + "---|" * 6]
        for group in GROUP_ORDER:
            if not self.has(group):
                continue
            entry = self.g(group)
            backends = entry["backend_requests"]
            total = sum(backends.values()) or 1
            cells = [group]
            for index in range(4):
                count = backends.get(f"sglang-{index}", 0)
                cells.append(f"{count} ({count / total * 100:.1f}%)")
            cells.append(f"{max(backends.values()) / total * 100:.1f}%")
            rows.append("| " + " | ".join(cells) + " |")
        return "\n".join(rows)

    def table_phases(self) -> str:
        header = (
            "| 组别 | 阶段 | 请求数 | 缓存命中率 | TTFT p95 (s) | E2E p95 (s) |"
        )
        rows = [header, "|" + "---|" * 6]
        for group in GROUP_ORDER:
            if not self.has(group):
                continue
            entry = self.g(group)
            for phase in ("steady", "burst", "recovery"):
                metrics = entry["phases"].get(phase)
                if not metrics:
                    continue
                rows.append(
                    "| "
                    + " | ".join(
                        [
                            group,
                            phase,
                            str(metrics["requests"]),
                            pct(metrics["cache_hit_rate"], 1),
                            fmt(metrics["ttft_p95"], 3),
                            fmt(metrics["latency_p95"], 3),
                        ]
                    )
                    + " |"
                )
        return "\n".join(rows)

    def table_tiers(self) -> str:
        header = "| 组别 | 热度层级 | 请求数 | 缓存命中率 | TTFT p95 (s) |"
        rows = [header, "|" + "---|" * 5]
        # tiers are derived from per-request rows and stored in run_meta-less summary
        summary_source = self.g(GROUP_ORDER[0])["summary"] if self.has(GROUP_ORDER[0]) else None
        for group in GROUP_ORDER:
            if not self.has(group):
                continue
            entry = self.g(group)
            tiers = entry.get("tiers") or {}
            for tier in TIER_ORDER:
                metrics = tiers.get(tier)
                if not metrics:
                    continue
                rows.append(
                    "| "
                    + " | ".join(
                        [
                            group,
                            TIER_TITLE.get(tier, tier),
                            str(metrics.get("requests", "")),
                            pct(metrics.get("cache_hit_rate"), 1),
                            fmt(metrics.get("ttft_p95"), 3),
                        ]
                    )
                    + " |"
                )
        return "\n".join(rows)

    def table_identity(self) -> str:
        header = "| 组别 | Ray Serve 路由配置 | max_ongoing_requests | 路由器 |"
        rows = [header, "|" + "---|" * 4]
        for group in GROUP_ORDER:
            if not self.has(group):
                continue
            policy = (self.g(group).get("run_meta") or {}).get("policy") or {}
            rows.append(
                "| "
                + " | ".join(
                    [
                        group,
                        str(policy.get("description", "")),
                        str(policy.get("max_ongoing_requests", "")),
                        str(policy.get("router_name", "")),
                    ]
                )
                + " |"
            )
        return "\n".join(rows)

    def table_health(self) -> str:
        header = "| 组别 | 成功/失败/不完整 | replica 数 | node 数 | backend 数 | dispatch_lag p95 (s) | client_queue p95 (s) |"
        rows = [header, "|" + "---|" * 7]
        for group in GROUP_ORDER:
            if not self.has(group):
                continue
            entry = self.g(group)
            summary = entry["summary"]
            rows.append(
                "| "
                + " | ".join(
                    [
                        group,
                        f"{summary['successful']}/{summary['failed']}/{summary['incomplete']}",
                        str(len(summary["replica_distribution"])),
                        str(len(summary["node_distribution"])),
                        str(len(summary["backend_distribution"])),
                        fmt(summary["dispatch_lag_s"]["p95"], 4),
                        fmt(summary["client_queue_s"]["p95"], 4),
                    ]
                )
                + " |"
            )
        return "\n".join(rows)


def build_static_sections(builder: ReportBuilder) -> str:
    a = builder.g("A") if builder.has("A") else {}
    b1 = builder.g("B1") if builder.has("B1") else {}
    b2 = builder.g("B2") if builder.has("B2") else {}
    c = builder.g("C") if builder.has("C") else {}
    d = builder.g("D") if builder.has("D") else {}
    return ""


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--numbers", default="/root/hw3/report/numbers.json")
    parser.add_argument("--out", default="/root/hw3/report/report.md")
    parser.add_argument("--name", default="姓名/学号")
    args = parser.parse_args(argv)

    numbers = json.loads(Path(args.numbers).read_text(encoding="utf-8"))
    builder = ReportBuilder(numbers)
    sections = [
        f"# 第三次挑战：比较并改进 RayServe 路由",
    ]
    Path(args.out).write_text("\n\n".join(sections), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
