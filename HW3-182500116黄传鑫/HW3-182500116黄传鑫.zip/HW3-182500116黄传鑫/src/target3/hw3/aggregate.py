"""Aggregate the A-D run results into the tables used by the report.

Reads ``results/<group>/<run>/summary.json`` (and ``run_meta.json`` when
present) and writes:

* ``results/comparison/table_main.csv``    - the main table of the report
* ``results/comparison/table_phases.csv``  - steady / burst / recovery split
* ``results/comparison/table_tiers.csv``   - per popularity tier
* ``results/comparison/table_backends.csv``- request distribution per backend
* ``results/comparison/summary_all.json``  - everything, machine readable
* ``results/comparison/table_main.md``     - markdown version of the main table
"""

from __future__ import annotations

import argparse
import csv
import json
import statistics
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

MAIN_COLUMNS = [
    ("group", "配置"),
    ("runs", "轮次"),
    ("success_rate", "成功率"),
    ("throughput_rps", "吞吐量 (req/s)"),
    ("cache_hit_rate", "缓存命中率"),
    ("prompt_tokens_total", "输入 token 总数"),
    ("cached_tokens_total", "命中 token 总数"),
    ("computed_prefill_tokens_total", "实际 Prefill token 数"),
    ("ttft_p50_s", "TTFT p50 (s)"),
    ("ttft_p95_s", "TTFT p95 (s)"),
    ("latency_p50_s", "E2E p50 (s)"),
    ("latency_p95_s", "E2E p95 (s)"),
    ("tpot_p95_s", "TPOT p95 (s)"),
    ("dispatch_lag_p95_s", "dispatch_lag p95 (s)"),
    ("client_queue_p95_s", "client_queue p95 (s)"),
    ("backend_0", "后端0 请求数"),
    ("backend_1", "后端1 请求数"),
    ("backend_2", "后端2 请求数"),
    ("backend_3", "后端3 请求数"),
    ("backend_max_share", "最大后端占比"),
]


def load_run(run_dir: Path) -> Dict[str, Any]:
    summary = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
    meta: Dict[str, Any] = {}
    meta_path = run_dir / "run_meta.json"
    if meta_path.exists():
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
    return {"run_dir": str(run_dir), "summary": summary, "meta": meta}


def discover(
    results_root: Path, groups: Optional[Iterable[str]] = None
) -> Dict[str, List[Dict[str, Any]]]:
    """Collect ``<group>/summary.json`` and ``<group>/<run>/summary.json``.

    ``B_candidates`` holds the two B candidates in separate sub directories, and
    variants that belong to a group (for example the D parameter study) are
    reported under their own name so that the main table stays a clean
    five-configuration comparison.
    """

    def collect(group_dir: Path) -> List[Dict[str, Any]]:
        runs: List[Dict[str, Any]] = []
        if (group_dir / "summary.json").exists():
            runs.append(load_run(group_dir))
        for child in sorted(p for p in group_dir.iterdir() if p.is_dir()):
            if (child / "summary.json").exists():
                runs.append(load_run(child))
            for grandchild in sorted(p for p in child.iterdir() if p.is_dir()):
                if (grandchild / "summary.json").exists():
                    runs.append(load_run(grandchild))
        return runs

    grouped: Dict[str, List[Dict[str, Any]]] = {}
    if (results_root / "A_default").exists():
        runs = collect(results_root / "A_default")
        if runs:
            grouped["A_default"] = runs

    candidates = results_root / "B_candidates"
    if candidates.exists():
        for child in sorted(p for p in candidates.iterdir() if p.is_dir()):
            name = child.name
            if name.startswith("calibration"):
                name = "B_calibration_128"
            elif name == "candidate-1":
                name = "B1_candidate"
            elif name == "candidate-2":
                name = "B2_candidate"
            runs = collect(child)
            if runs:
                grouped[name] = runs

    for name in ("C_affinity", "D_improved"):
        path = results_root / name
        if path.exists():
            runs = collect(path)
            if runs:
                grouped[name] = runs

    d_variants = results_root / "D_variants"
    if d_variants.exists():
        for child in sorted(p for p in d_variants.iterdir() if p.is_dir()):
            runs = collect(child)
            if runs:
                grouped[f"D_variant_{child.name}"] = runs

    if groups:
        allowed = set(groups)
        grouped = {k: v for k, v in grouped.items() if k in allowed}
    return grouped


def _mean(values: List[float]) -> Optional[float]:
    clean = [v for v in values if v is not None]
    return statistics.fmean(clean) if clean else None


def _range(values: List[float]) -> Optional[List[float]]:
    clean = [v for v in values if v is not None]
    return [min(clean), max(clean)] if clean else None


def summarize_group(name: str, runs: List[Dict[str, Any]]) -> Dict[str, Any]:
    summaries = [r["summary"] for r in runs]
    first = summaries[0]

    def pick(path: List[str]) -> List[float]:
        out = []
        for summary in summaries:
            node: Any = summary
            for key in path:
                node = node.get(key) if isinstance(node, dict) else None
            out.append(node)
        return out

    backend_keys = sorted(first["backend_distribution"].keys())
    backends = {key: _mean(pick(["backend_distribution", key])) or 0.0 for key in backend_keys}
    total_backend = sum(backends.values()) or 1.0

    return {
        "group": name,
        "runs": len(runs),
        "run_names": [s["run_name"] for s in summaries],
        "model": first["model"],
        "router_name": first["router_name"],
        "max_ongoing_requests": first["max_ongoing_requests"],
        "success_rate": _mean(
            [s["successful"] / s["requests"] for s in summaries]
        ),
        "throughput_rps": _mean([s["throughput_rps"] for s in summaries]),
        "throughput_rps_range": _range([s["throughput_rps"] for s in summaries]),
        "cache_hit_rate": _mean([s["cache_hit_rate"] for s in summaries]),
        "cache_hit_rate_range": _range([s["cache_hit_rate"] for s in summaries]),
        "prompt_tokens_total": _mean([s["prompt_tokens_total"] for s in summaries]),
        "cached_tokens_total": _mean([s["cached_tokens_total"] for s in summaries]),
        "computed_prefill_tokens_total": _mean(
            [s["computed_prefill_tokens_total"] for s in summaries]
        ),
        "ttft_p50_s": _mean(pick(["ttft_s", "p50"])),
        "ttft_p95_s": _mean(pick(["ttft_s", "p95"])),
        "ttft_p99_s": _mean(pick(["ttft_s", "p99"])),
        "latency_p50_s": _mean(pick(["latency_s", "p50"])),
        "latency_p95_s": _mean(pick(["latency_s", "p95"])),
        "latency_p99_s": _mean(pick(["latency_s", "p99"])),
        "tpot_p95_s": _mean(pick(["tpot_s", "p95"])),
        "dispatch_lag_p95_s": _mean(pick(["dispatch_lag_s", "p95"])),
        "client_queue_p95_s": _mean(pick(["client_queue_s", "p95"])),
        "backend_distribution": backends,
        "backend_share": {k: v / total_backend for k, v in backends.items()},
        "backend_max_share": max(backends.values()) / total_backend,
        "node_distribution": first["node_distribution"],
        "replica_distribution": first["replica_distribution"],
        "elapsed_s": _mean([s["elapsed_s"] for s in summaries]),
        "planned_duration_s": _mean([s["planned_duration_s"] for s in summaries]),
        "traffic_phases": {
            phase: {
                key: _mean(
                    [
                        s["traffic_phases"][phase][key]
                        for s in summaries
                        if phase in s.get("traffic_phases", {})
                    ]
                )
                for key in ("cache_hit_rate", "successful")
            }
            | {
                "ttft_p95_s": _mean(
                    [
                        s["traffic_phases"][phase]["ttft_s"]["p95"]
                        for s in summaries
                        if phase in s.get("traffic_phases", {})
                    ]
                ),
                "latency_p95_s": _mean(
                    [
                        s["traffic_phases"][phase]["latency_s"]["p95"]
                        for s in summaries
                        if phase in s.get("traffic_phases", {})
                    ]
                ),
            }
            for phase in first.get("traffic_phases", {})
        },
        "popularity_tiers": {
            tier: {
                "requests": _mean(
                    [
                        s["popularity_tiers"][tier]["requests"]
                        for s in summaries
                        if tier in s.get("popularity_tiers", {})
                    ]
                ),
                "cache_hit_rate": _mean(
                    [
                        s["popularity_tiers"][tier]["cache_hit_rate"]
                        for s in summaries
                        if tier in s.get("popularity_tiers", {})
                    ]
                ),
                "ttft_p95_s": _mean(
                    [
                        s["popularity_tiers"][tier]["ttft_s"]["p95"]
                        for s in summaries
                        if tier in s.get("popularity_tiers", {})
                    ]
                ),
            }
            for tier in first.get("popularity_tiers", {})
        },
        "policy": (runs[0]["meta"] or {}).get("policy", {}),
        "verification": [
            (r["meta"] or {}).get("verification", {}) for r in runs
        ],
    }


def _fmt(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float):
        return f"{value:.4f}"
    return str(value)


def write_csv(path: Path, columns, rows: List[Dict[str, Any]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow([label for _, label in columns])
        for row in rows:
            writer.writerow([_fmt(row.get(key)) for key, _ in columns])


def write_markdown(path: Path, columns, rows: List[Dict[str, Any]]) -> None:
    lines = ["| " + " | ".join(label for _, label in columns) + " |"]
    lines.append("|" + "|".join(["---"] * len(columns)) + "|")
    for row in rows:
        lines.append("| " + " | ".join(_fmt(row.get(key)) for key, _ in columns) + " |")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", default="/root/hw3/results")
    parser.add_argument("--out", default=None)
    parser.add_argument(
        "--groups",
        nargs="*",
        default=None,
        help="restrict to these result sub directories",
    )
    args = parser.parse_args(argv)

    results_root = Path(args.results)
    out_dir = Path(args.out) if args.out else results_root / "comparison"
    out_dir.mkdir(parents=True, exist_ok=True)

    grouped = discover(results_root, args.groups)
    if not grouped:
        raise SystemExit(f"no results found under {results_root}")

    order = [
        "A_default",
        "B1_candidate",
        "B2_candidate",
        "B_calibration_128",
        "C_affinity",
        "D_improved",
        "D_variant_relaxed-0.7",
        "D_variant_tight-0.3",
    ]
    names = [n for n in order if n in grouped] + [n for n in grouped if n not in order]

    per_group = {name: summarize_group(name, grouped[name]) for name in names}
    rows = [per_group[name] for name in names]

    ordered_backends = sorted(
        {key for row in rows for key in row["backend_distribution"]}
    )

    # flat backend distribution columns (stable order across groups)
    for row in rows:
        for index, key in enumerate(ordered_backends):
            row[f"backend_{index}"] = row["backend_distribution"].get(key, 0.0)

    write_csv(out_dir / "table_main.csv", MAIN_COLUMNS, rows)
    write_markdown(out_dir / "table_main.md", MAIN_COLUMNS, rows)

    phase_columns = [
        ("group", "配置"),
        ("phase", "阶段"),
        ("successful", "成功请求"),
        ("cache_hit_rate", "缓存命中率"),
        ("ttft_p95_s", "TTFT p95 (s)"),
        ("latency_p95_s", "E2E p95 (s)"),
    ]
    phase_rows = []
    for row in rows:
        for phase, metrics in row["traffic_phases"].items():
            phase_rows.append({"group": row["group"], "phase": phase, **metrics})
    write_csv(out_dir / "table_phases.csv", phase_columns, phase_rows)
    write_markdown(out_dir / "table_phases.md", phase_columns, phase_rows)

    tier_columns = [
        ("group", "配置"),
        ("tier", "热度层级"),
        ("requests", "请求数"),
        ("cache_hit_rate", "缓存命中率"),
        ("ttft_p95_s", "TTFT p95 (s)"),
    ]
    tier_rows = []
    for row in rows:
        for tier, metrics in row["popularity_tiers"].items():
            tier_rows.append({"group": row["group"], "tier": tier, **metrics})
    write_csv(out_dir / "table_tiers.csv", tier_columns, tier_rows)
    write_markdown(out_dir / "table_tiers.md", tier_columns, tier_rows)

    def backend_values(row: Dict[str, Any], key: str) -> Optional[float]:
        return row["backend_distribution"].get(key)

    def backend_share_values(row: Dict[str, Any], key: str) -> Optional[float]:
        return row["backend_share"].get(key)

    backend_columns = [("group", "配置")]
    backend_columns += [
        (f"backend_{index}", f"后端{index}") for index in range(len(ordered_backends))
    ]
    backend_columns += [
        (f"backend_share_{index}", f"后端{index} 占比")
        for index in range(len(ordered_backends))
    ]
    backend_rows = []
    for row in rows:
        entry: Dict[str, Any] = {"group": row["group"]}
        for index, key in enumerate(ordered_backends):
            entry[f"backend_{index}"] = backend_values(row, key)
            entry[f"backend_share_{index}"] = backend_share_values(row, key)
        backend_rows.append(entry)
    write_csv(out_dir / "table_backends.csv", backend_columns, backend_rows)
    write_markdown(out_dir / "table_backends.md", backend_columns, backend_rows)

    (out_dir / "summary_all.json").write_text(
        json.dumps(per_group, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    # baseline deltas relative to A
    baseline = per_group.get("A_default")
    if baseline:
        deltas = {}
        for name, row in per_group.items():
            if name == "A_default":
                continue
            deltas[name] = {
                "throughput_delta_pct": _pct(row["throughput_rps"], baseline["throughput_rps"]),
                "cache_hit_delta_pp": _pp(row["cache_hit_rate"], baseline["cache_hit_rate"]),
                "prefill_delta_pct": _pct(
                    row["computed_prefill_tokens_total"],
                    baseline["computed_prefill_tokens_total"],
                ),
                "ttft_p95_delta_pct": _pct(row["ttft_p95_s"], baseline["ttft_p95_s"]),
                "latency_p95_delta_pct": _pct(
                    row["latency_p95_s"], baseline["latency_p95_s"]
                ),
                "backend_max_share_delta_pp": _pp(
                    row["backend_max_share"], baseline["backend_max_share"]
                ),
            }
        (out_dir / "deltas_vs_A.json").write_text(
            json.dumps(deltas, indent=2, ensure_ascii=False), encoding="utf-8"
        )

    print((out_dir / "table_main.md").read_text(encoding="utf-8"))
    print(f"[aggregate] wrote tables to {out_dir}")
    return 0


def _pct(new: Optional[float], base: Optional[float]) -> Optional[float]:
    if new is None or not base:
        return None
    return (new - base) / base * 100.0


def _pp(new: Optional[float], base: Optional[float]) -> Optional[float]:
    if new is None or base is None:
        return None
    return (new - base) * 100.0


if __name__ == "__main__":
    raise SystemExit(main())
