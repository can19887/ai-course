"""Bring up the logical Ray cluster and the four SGLang backends.

Usage (inside the repo root)::

    python -m hw3.start_experiment --model /root/autodl-tmp/models/Qwen3-4B-Instruct-2507

It performs, in order:

1. build 1 Ray head node + 4 logical worker nodes (``ray.cluster_utils.Cluster``)
2. write ``run/topology.json`` (node id, ip, gpu, backend url per node)
3. reserve one placement-group bundle per worker node
4. start one SGLang server per worker node, pinned to that node's GPU
5. wait for all four ``/health`` endpoints and report the layout
"""

from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path

os.environ.setdefault("RAY_SERVE_DISABLE_PLACEMENT_GROUP", "1")
os.environ.setdefault("RAY_SERVE_SESSION_ID_HEADER_KEY", "x-session-id")

import ray  # noqa: E402

from . import sglang_launcher  # noqa: E402
from .cluster import create_placement_group, start_cluster  # noqa: E402

RUN_DIR = Path("/root/hw3/run")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", default=sglang_launcher.DEFAULT_MODEL_PATH)
    parser.add_argument("--attention-backend", default="flashinfer")
    parser.add_argument("--page-size", type=int, default=1)
    parser.add_argument("--mem-fraction-static", type=float, default=0.75)
    parser.add_argument("--max-running-requests", type=int, default=256)
    parser.add_argument("--chunked-prefill-size", type=int, default=4096)
    parser.add_argument("--extra-arg", action="append", default=[])
    parser.add_argument("--health-timeout", type=float, default=1500.0)
    parser.add_argument("--topology", default=str(RUN_DIR / "topology.json"))
    parser.add_argument("--skip-sglang", action="store_true")
    parser.add_argument("--placement-group-only", action="store_true")
    args = parser.parse_args(argv)

    RUN_DIR.mkdir(parents=True, exist_ok=True)
    cluster, topology = start_cluster()
    topology.save(args.topology)
    print(f"[setup] wrote topology to {args.topology}", flush=True)

    if not args.placement_group_only:
        create_placement_group(topology)
        print("[setup] placement group ready (4 bundles, SPREAD)", flush=True)

    if args.skip_sglang or args.placement_group_only:
        print("[setup] skipping SGLang launch; cluster stays up", flush=True)
        return 0

    refs = sglang_launcher.launch_all(
        topology,
        model_path=args.model,
        attention_backend=args.attention_backend,
        page_size=args.page_size,
        mem_fraction_static=args.mem_fraction_static,
        max_running_requests=args.max_running_requests,
        chunked_prefill_size=args.chunked_prefill_size,
        extra_args=args.extra_arg or None,
    )
    print("[setup] launched SGLang actors:", sorted(refs), flush=True)

    t0 = time.time()
    ready = asyncio_run(sglang_launcher.wait_healthy(topology, timeout_s=args.health_timeout))
    print(
        f"[setup] health after {time.time() - t0:.1f}s: "
        + json.dumps(ready, ensure_ascii=False),
        flush=True,
    )
    if not all(ready.values()):
        print("[setup] ERROR: not all backends became healthy", flush=True)
        for backend, actor in refs.items():
            try:
                print(f"---- {backend} log tail ----\n{ray.get(actor.tail.remote(30))}", flush=True)
            except Exception as exc:  # pragma: no cover
                print(f"---- {backend} log unavailable: {exc!r}", flush=True)
        return 2

    (RUN_DIR / "sglang_actors.json").write_text(
        json.dumps(
            {
                "actors": sorted(refs),
                "servers": sglang_launcher.server_info(topology),
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print(
        "[setup] ready: "
        + json.dumps(sglang_launcher.server_info(topology), indent=2),
        flush=True,
    )
    return 0


def asyncio_run(coro):
    import asyncio

    return asyncio.run(coro)


if __name__ == "__main__":
    raise SystemExit(main())
