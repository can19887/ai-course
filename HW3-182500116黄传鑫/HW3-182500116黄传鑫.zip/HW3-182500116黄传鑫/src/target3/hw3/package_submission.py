"""Assemble the final submission folder and zip.

Layout required by the assignment::

    HW3-<name>/
    ├── README.md
    ├── report.pdf
    ├── AI使用说明情况（第三次挑战）.pdf
    ├── src/
    ├── scripts/
    ├── target1/            (this challenge is target 3; kept as a placeholder note)
    ├── target3/            (this work: code + results summary tables)
    └── results/
        ├── target3/{A_default,B_candidates,C_affinity,D_improved}/...
        └── comparison/
"""

from __future__ import annotations

import argparse
import json
import shutil
import zipfile
from pathlib import Path

EXCLUDE_DIRS = {"__pycache__", ".ipynb_checkpoints", ".git"}
EXCLUDE_SUFFIX = {".pyc", ".pyo", ".part", ".incomplete"}


def copy_tree(src: Path, dst: Path) -> None:
    dst.mkdir(parents=True, exist_ok=True)
    for item in src.iterdir():
        if item.name in EXCLUDE_DIRS:
            continue
        if item.suffix in EXCLUDE_SUFFIX:
            continue
        target = dst / item.name
        if item.is_dir():
            copy_tree(item, target)
        else:
            shutil.copy2(item, target)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--name", required=True, help="student name or id")
    parser.add_argument("--work", default="/root/hw3")
    parser.add_argument("--out", default="/root/hw3/dist")
    args = parser.parse_args()

    work = Path(args.work)
    out = Path(args.out)
    stage = out / f"HW3-{args.name}"
    if stage.exists():
        shutil.rmtree(stage)
    stage.mkdir(parents=True)

    # 1. sources and scripts
    copy_tree(work / "src", stage / "src")
    copy_tree(work / "scripts", stage / "scripts")
    for extra in ("requirements.txt", "README.md"):
        candidate = work / extra
        if candidate.exists():
            shutil.copy2(candidate, stage / extra)

    # 2. documents
    for doc in ("report.pdf", "AI使用说明情况（第三次挑战）.pdf"):
        candidate = work / "report" / doc
        if candidate.exists():
            shutil.copy2(candidate, stage / doc)

    # 3. results (raw artifacts only, no virtualenvs / caches)
    copy_tree(work / "results", stage / "results")

    # 4. target3 mirror of the comparison tables for convenience
    target3 = stage / "target3"
    target3.mkdir(parents=True, exist_ok=True)
    comparison = work / "results" / "comparison"
    if comparison.exists():
        copy_tree(comparison, target3 / "comparison")
    (target3 / "README.md").write_text(
        "# target3 说明\n\n"
        "本目录对应挑战三（四副本 Ray Serve 路由比较）。\n\n"
        "- 代码：`../src/hw3/`（集群、SGLang、Serve Deployment、路由策略、实验脚本）\n"
        "- 原始结果：`../results/target3/`（每组实验的 config/warmups/requests/summary/run_meta）\n"
        "- 汇总表：`comparison/`（报告主表、分阶段表、分层表、后端分布表）\n\n"
        "target1 属于另一次挑战，本次提交未包含，仅保留目录说明。\n",
        encoding="utf-8",
    )
    (stage / "target1").mkdir(exist_ok=True)
    (stage / "target1" / "README.md").write_text(
        "# target1\n\n本次提交只包含挑战三（target3）的内容。\n",
        encoding="utf-8",
    )

    # 5. zip
    zip_path = out / f"HW3-{args.name}.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(stage.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(out))
    size_mb = zip_path.stat().st_size / 1024 / 1024
    print(json.dumps(
        {
            "stage": str(stage),
            "zip": str(zip_path),
            "size_mb": round(size_mb, 2),
            "files": sum(1 for p in stage.rglob("*") if p.is_file()),
        },
        indent=2,
        ensure_ascii=False,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
