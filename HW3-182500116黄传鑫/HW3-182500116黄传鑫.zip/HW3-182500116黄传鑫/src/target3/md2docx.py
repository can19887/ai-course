#!/usr/bin/env python3
"""Minimal markdown -> docx converter for the HW3 report / AI-usage documents.

Supported syntax:
  # / ## / ### headings, plain paragraphs, - bullets, 1. numbered items,
  | tables |, ![caption](path) images, **bold** inline, `code` in Word style,
  blank-line separated blocks.
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

CJK_FONT = "Microsoft YaHei"
LATIN_FONT = "Cambria"
MONO_FONT = "Consolas"


def set_run_fonts(run, *, size=None, bold=None, mono=False) -> None:
    run.font.name = MONO_FONT if mono else LATIN_FONT
    # `run._element.rPr` only exists once a font property has been set; reuse
    # the element the setter just created, and create one if it is still None.
    rpr = run._element.get_or_add_rPr()
    rpr.rFonts.set(qn("w:eastAsia"), CJK_FONT)
    if size:
        run.font.size = Pt(size)
    if bold is not None:
        run.font.bold = bold


def configure(doc: Document) -> None:
    style = doc.styles["Normal"]
    style.font.name = LATIN_FONT
    style.font.size = Pt(10.5)
    style.element.rPr.rFonts.set(qn("w:eastAsia"), CJK_FONT)
    for name, size in (("Heading 1", 18), ("Heading 2", 14), ("Heading 3", 12)):
        heading = doc.styles[name]
        heading.font.name = LATIN_FONT
        heading.font.size = Pt(size)
        heading.font.color.rgb = RGBColor(0x1F, 0x3B, 0x73)
        heading.element.rPr.rFonts.set(qn("w:eastAsia"), CJK_FONT)
    for section in doc.sections:
        section.left_margin = Cm(2.2)
        section.right_margin = Cm(2.2)
        section.top_margin = Cm(2.0)
        section.bottom_margin = Cm(2.0)


INLINE = re.compile(r"(\*\*[^*]+\*\*|`[^`]+`)")


def add_rich_text(paragraph, text: str, *, size=None, bold: bool = False) -> None:
    for part in INLINE.split(text):
        if not part:
            continue
        if part.startswith("**") and part.endswith("**"):
            run = paragraph.add_run(part[2:-2])
            set_run_fonts(run, size=size, bold=True)
        elif part.startswith("`") and part.endswith("`"):
            run = paragraph.add_run(part[1:-1])
            set_run_fonts(run, size=size, mono=True, bold=bold or None)
        else:
            run = paragraph.add_run(part)
            set_run_fonts(run, size=size, bold=bold or None)


def add_table(doc: Document, rows: list[list[str]]) -> None:
    table = doc.add_table(rows=len(rows), cols=len(rows[0]))
    table.style = "Light Grid Accent 1"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for r, row in enumerate(rows):
        for c, cell in enumerate(row):
            paragraph = table.cell(r, c).paragraphs[0]
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            add_rich_text(paragraph, cell, size=8.5, bold=(r == 0))


def convert(md_path: Path, docx_path: Path, *, images_root: Path | None = None) -> None:
    doc = Document()
    configure(doc)
    lines = md_path.read_text(encoding="utf-8").splitlines()
    index = 0
    while index < len(lines):
        line = lines[index].rstrip()
        stripped = line.strip()

        if not stripped:
            index += 1
            continue

        if stripped.startswith("<!--"):
            while index < len(lines) and "-->" not in lines[index]:
                index += 1
            index += 1
            continue

        if stripped.startswith("#"):
            level = len(stripped) - len(stripped.lstrip("#"))
            text = stripped[level:].strip()
            paragraph = doc.add_heading(level=min(level, 3))
            add_rich_text(paragraph, text)
            index += 1
            continue

        if stripped.startswith("!["):
            # NB: use search, not match -- Python's re treats full width spaces
            # (U+3000) as \s, so match() would silently skip captions that
            # start with an ideographic space.
            match = re.search(r"!\[(.*?)\]\((.*?)\)", stripped)
            if match:
                caption, src = match.groups()
                path = Path(src)
                if images_root and not path.is_absolute():
                    path = images_root / src
                path = path.resolve()
                if path.exists():
                    doc.add_picture(str(path), width=Cm(16.5))
                    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
                    if caption:
                        cap = doc.add_paragraph()
                        cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
                        run = cap.add_run(caption)
                        set_run_fonts(run, size=9)
                else:
                    print(f"[warn] image not found: {path}")
            index += 1
            continue

        if stripped.startswith("```"):
            index += 1
            block: list[str] = []
            while index < len(lines) and not lines[index].strip().startswith("```"):
                block.append(lines[index])
                index += 1
            index += 1  # closing fence
            for raw in block:
                paragraph = doc.add_paragraph()
                paragraph.paragraph_format.space_after = Pt(0)
                paragraph.paragraph_format.space_before = Pt(0)
                run = paragraph.add_run(raw if raw.strip() else " ")
                set_run_fonts(run, size=9, mono=True)
            doc.add_paragraph()
            continue

        if stripped.startswith("|"):
            rows: list[list[str]] = []
            while index < len(lines) and lines[index].strip().startswith("|"):
                raw = lines[index].strip().strip("|")
                cells = [c.strip() for c in raw.split("|")]
                if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                    rows.append(cells)
                index += 1
            if rows:
                width = max(len(r) for r in rows)
                rows = [r + [""] * (width - len(r)) for r in rows]
                add_table(doc, rows)
                doc.add_paragraph()
            continue

        if stripped.startswith("- ") or stripped.startswith("* "):
            paragraph = doc.add_paragraph(style="List Bullet")
            add_rich_text(paragraph, stripped[2:])
            index += 1
            continue

        match = re.match(r"^(\d+)\.\s+(.*)$", stripped)
        if match:
            paragraph = doc.add_paragraph(style="List Number")
            add_rich_text(paragraph, match.group(2))
            index += 1
            continue

        paragraph = doc.add_paragraph()
        add_rich_text(paragraph, stripped)
        index += 1

    docx_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(docx_path)
    print("wrote", docx_path)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("markdown")
    parser.add_argument("docx")
    parser.add_argument("--images-root", default=None)
    args = parser.parse_args()
    convert(
        Path(args.markdown),
        Path(args.docx),
        images_root=Path(args.images_root) if args.images_root else None,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
