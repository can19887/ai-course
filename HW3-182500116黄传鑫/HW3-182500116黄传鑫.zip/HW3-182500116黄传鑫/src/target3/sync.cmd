@echo off
setlocal
set KEY=C:\Users\bigmo\Documents\deepseek-harness\default-workspace\hw3\.ssh\id_ed25519
set HOST=root@connect.westb.seetacloud.com
set PORT=19037
set LOCAL=C:\Users\bigmo\Documents\deepseek-harness\default-workspace\hw3
ssh -i "%KEY%" -p %PORT% -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o BatchMode=yes %HOST% "mkdir -p /root/hw3/src /root/hw3/scripts /root/hw3/report /root/hw3/run /root/hw3/results"
scp -q -i "%KEY%" -P %PORT% -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -r "%LOCAL%\src\hw3" %HOST%:/root/hw3/src/
scp -q -i "%KEY%" -P %PORT% -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null "%LOCAL%\scripts\*.sh" %HOST%:/root/hw3/scripts/
ssh -i "%KEY%" -p %PORT% -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o BatchMode=yes %HOST% "sed -i 's/\r$//' /root/hw3/scripts/*.sh; chmod +x /root/hw3/scripts/*.sh; ls /root/hw3/src/hw3 | tr '\n' ' '; echo; ls /root/hw3/scripts | tr '\n' ' '"
echo SYNC_DONE
