"""Assemble the final submission folder and zip (runs on the local machine).

Required layout::

    HW3-<name>/
    ├── README.md
    ├── report.pdf
    ├── AI使用说明情况（第三次挑战）.pdf
    ├── src/
    ├── scripts/
    ├── target1/            (placeholder: this submission covers target 3)
    ├── target3/
    └── results/
        └── target3/{A_default,B_candidates,C_affinity,D_improved,D_variants}/...
"""

from __future__ import annotations

import argparse
import json
import shutil
import zipfile
from pathlib import Path

EXCLUDE_DIRS = {"__pycache__", ".ipynb_checkpoints", ".git", "preview", "run"}
EXCLUDE_SUFFIX = {".pyc", ".pyo", ".part", ".incomplete", ".docx"}

SOURCE_SUBDIRS = [
    ("results/A_default", "A_default"),
    ("results/B_candidates/candidate-1", "B_candidates/candidate-1"),
    ("results/B_candidates/candidate-2", "B_candidates/candidate-2"),
    ("results/B_candidates/calibration-128", "B_candidates/calibration-128"),
    ("results/C_affinity", "C_affinity"),
    ("results/D_improved", "D_improved"),
    ("results/D_variants/relaxed-0.7", "D_variants/relaxed-0.7"),
    ("results/D_variants/tight-0.3", "D_variants/tight-0.3"),
    ("results/comparison", "comparison"),
]


def copy_tree(src: Path, dst: Path) -> None:
    dst.mkdir(parents=True, exist_ok=True)
    for item in sorted(src.iterdir()):
        if item.name in EXCLUDE_DIRS or item.suffix in EXCLUDE_SUFFIX:
            continue
        target = dst / item.name
        if item.is_dir():
            copy_tree(item, target)
        else:
            shutil.copy2(item, target)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--name", required=True, help="student name or id")
    parser.add_argument("--work", default=str(Path(__file__).resolve().parents[2]))
    parser.add_argument("--out", default=None)
    args = parser.parse_args()

    work = Path(args.work).resolve()
    out = Path(args.out).resolve() if args.out else work / "dist"
    stage = out / f"HW3-{args.name}"
    if stage.exists():
        shutil.rmtree(stage)
    stage.mkdir(parents=True)

    # 1. code and scripts
    copy_tree(work / "src", stage / "src")
    copy_tree(work / "pack" / "scripts", stage / "scripts")
    if (work / "pack" / "sync.cmd").exists():
        shutil.copy2(work / "pack" / "sync.cmd", stage / "scripts" / "sync.cmd")
    shutil.copy2(work / "pack" / "README.md", stage / "README.md")

    # 2. documents
    for doc in ("report.pdf", "AI使用说明情况（第三次挑战）.pdf"):
        candidate = work / "report" / doc
        if candidate.exists():
            shutil.copy2(candidate, stage / doc)
        else:
            print(f"[warn] missing deliverable: {candidate}")

    # 3. raw results, grouped by target
    target3 = stage / "results" / "target3"
    for rel, dest in SOURCE_SUBDIRS:
        src = work / rel
        if src.exists():
            copy_tree(src, target3 / dest)
        else:
            print(f"[warn] missing results: {src}")

    # 4. target3 landing page + target1 placeholder
    landing = stage / "target3"
    landing.mkdir(parents=True, exist_ok=True)
    (landing / "README.md").write_text(
        "# target3：比较并改进 RayServe 路由\n\n"
        "本次提交对应挑战三。\n\n"
        "| 内容 | 位置 |\n| --- | --- |\n"
        "| 集群 / SGLang / Ray Serve 代码 | `../src/hw3/` |\n"
        "| 启动与实验脚本 | `../scripts/` |\n"
        "| A 组原始结果 | `../results/target3/A_default/` |\n"
        "| B 两个候选 + 128 标定 | `../results/target3/B_candidates/` |\n"
        "| C 组（一致性哈希） | `../results/target3/C_affinity/` |\n"
        "| D 组（自定义前缀亲和） | `../results/target3/D_improved/` |\n"
        "| D 参数研究（0.7 / 0.3） | `../results/target3/D_variants/` |\n"
        "| 汇总表与对照工具输出 | `../results/target3/comparison/` |\n\n"
        "每组目录内包含 `config.json`、`warmups.csv`、`requests.csv`、`summary.json`、"
        "`deploy.json`（replica→node→backend 映射与清缓存结果）、`run_meta.json`（GPU 采样与验收结论）。\n",
        encoding="utf-8",
    )
    (stage / "target1").mkdir(exist_ok=True)
    (stage / "target1" / "README.md").write_text(
        "# target1\n\n本次提交只包含挑战三（target3）的内容，target1 属于另一次挑战。\n",
        encoding="utf-8",
    )

    # 5. zip
    zip_path = out / f"HW3-{args.name}.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(stage.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(out))

    files = [p for p in stage.rglob("*") if p.is_file()]
    total_mb = sum(p.stat().st_size for p in files) / 1024 / 1024
    print(
        json.dumps(
            {
                "stage": str(stage),
                "zip": str(zip_path),
                "zip_mb": round(zip_path.stat().st_size / 1024 / 1024, 2),
                "files": len(files),
                "uncompressed_mb": round(total_mb, 2),
                "top_level": sorted(p.name for p in stage.iterdir()),
            },
            indent=2,
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
