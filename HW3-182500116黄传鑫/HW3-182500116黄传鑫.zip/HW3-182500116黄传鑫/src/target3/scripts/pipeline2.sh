#!/usr/bin/env bash
# Orchestrator for batch 2 (C and D) plus all post-processing.
set -uo pipefail
export PATH=/root/miniconda3/bin:$PATH
export PYTHONPATH=/root/hw3/src
cd /root/hw3
mkdir -p logs run report results

LOG=logs/pipeline.log
status() {
  printf '{"state":"%s","detail":"%s","ts":"%s"}\n' "$1" "$2" "$(date -Is)" > run/status.json
  echo "[$(date +%H:%M:%S)] $1 :: $2" >> "$LOG"
}

status "batch2" "C, D"
bash scripts/run_batch2.sh >> "$LOG" 2>&1
code=$?
status "batch2_done" "exit=$code"

python -m hw3.aggregate --results results >> "$LOG" 2>&1
python -m hw3.make_numbers --results results --out report/numbers.json >> "$LOG" 2>&1
python -m hw3.make_figures --results results --out report/fig >> "$LOG" 2>&1

# the course comparison tool, as required by the workload README
WORKLOAD_REPO=/root/hw3/26fall-HW-data/workloads/hw2/target3-routing-policies
if [ -f "$WORKLOAD_REPO/compare_runs.py" ]; then
  python "$WORKLOAD_REPO/compare_runs.py" \
    --baseline A \
    --run A=results/A_default/summary.json \
    --run B1=results/B_candidates/candidate-1/summary.json \
    --run B2=results/B_candidates/candidate-2/summary.json \
    --run C=results/C_affinity/summary.json \
    --run D=results/D_improved/summary.json \
    --output results/comparison/comparison.json >> "$LOG" 2>&1
  echo "compare_runs exit=$?" >> "$LOG"
fi
status "analysis_done" "tables, figures, numbers.json"
exit $code
