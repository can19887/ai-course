#!/usr/bin/env bash
# Start the logical Ray cluster (1 head + 4 workers) and one SGLang server per GPU.
# Idempotent: kills a previous SGLang round first.
set -uo pipefail
export PATH=/root/miniconda3/bin:$PATH
export PYTHONPATH=/root/hw3/src
cd /root/hw3
LOG=/root/hw3/logs/start_experiment.log
mkdir -p /root/hw3/logs /root/hw3/run /root/hw3/results /root/hw3/report

MODEL=${MODEL:-/root/autodl-tmp/models/Qwen3-4B-Instruct-2507}
ATTN=${ATTN:-flashinfer}
MEMFRAC=${MEMFRAC:-0.75}
MAXRUN=${MAXRUN:-256}
CHUNK=${CHUNK:-4096}

# --- 1. tear down a previous round -----------------------------------------
pkill -f "hw3.start_experiment" 2>/dev/null
python - <<'PY' 2>/dev/null || true
import ray
try:
    ray.init(address="auto", ignore_reinit_error=True, log_to_driver=False)
    for i in range(8):
        try:
            actor = ray.get_actor(f"hw3-sglang-{i}")
            try:
                ray.get(actor.stop.remote(), timeout=120)
            except Exception:
                pass
            ray.kill(actor, no_restart=True)
            print("killed hw3-sglang-%d" % i)
        except Exception:
            pass
    ray.shutdown()
except Exception as exc:
    print("cleanup skipped:", exc)
PY
pkill -f "raylet" 2>/dev/null
pkill -f "sglang.launch_server" 2>/dev/null
pkill -f "gcs_server" 2>/dev/null
sleep 5
rm -rf /tmp/ray/*
echo "[start] previous round cleaned"

# --- 2. start the cluster and the backends ---------------------------------
nohup python -u -m hw3.start_experiment \
  --model "$MODEL" \
  --attention-backend "$ATTN" \
  --mem-fraction-static "$MEMFRAC" \
  --max-running-requests "$MAXRUN" \
  --chunked-prefill-size "$CHUNK" \
  > "$LOG" 2>&1 &
echo "[start] driver pid=$! log=$LOG"

# --- 3. follow the log until the cluster reports healthy or fails ----------
for i in $(seq 1 200); do
  sleep 10
  if grep -q "\[setup\] ready:" "$LOG" 2>/dev/null; then
    echo "[start] OK"
    tail -30 "$LOG"
    exit 0
  fi
  if grep -q "ERROR: not all backends became healthy" "$LOG" 2>/dev/null; then
    echo "[start] FAILED"
    tail -40 "$LOG"
    exit 2
  fi
done
echo "[start] TIMEOUT waiting for health"
tail -40 "$LOG"
exit 3
