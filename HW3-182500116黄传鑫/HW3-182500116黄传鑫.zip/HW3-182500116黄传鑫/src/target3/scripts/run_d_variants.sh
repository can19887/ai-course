#!/usr/bin/env bash
# D parameter study: how much affinity can we buy before hotspots appear?
set -uo pipefail
export PATH=/root/miniconda3/bin:$PATH
export PYTHONPATH=/root/hw3/src
cd /root/hw3
mkdir -p results/D_variants/tight-0.3 logs

bash scripts/run_group.sh D_tight D_tight_run1 results/D_variants/tight-0.3
code=$?

echo "=== D variants summary ==="
python - <<'PY'
import json
from pathlib import Path
for label, rel in [
    ("B2(mor=64,p2c)", "B_candidates/candidate-2"),
    ("D(ratio=0.7)", "D_improved"),
    ("D(ratio=0.3)", "D_variants/tight-0.3"),
    ("C(strict hash)", "C_affinity"),
]:
    path = Path("results") / rel / "summary.json"
    if not path.exists():
        print(label, "MISSING"); continue
    s = json.loads(path.read_text())
    dist = s['backend_distribution']
    tot = sum(dist.values())
    print(
        f"{label}: thr={s['throughput_rps']:.2f} cache={s['cache_hit_rate']*100:.1f}% "
        f"prefill={s['computed_prefill_tokens_total']} ttft p50={s['ttft_s']['p50']:.2f} "
        f"p95={s['ttft_s']['p95']:.2f} e2e_p95={s['latency_s']['p95']:.2f} "
        f"maxshare={max(dist.values())/tot*100:.1f}% dist={dist}"
    )
PY
echo "D_VARIANTS_DONE exit=$code"
