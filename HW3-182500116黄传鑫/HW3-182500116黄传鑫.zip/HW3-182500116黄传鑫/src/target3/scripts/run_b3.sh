#!/usr/bin/env bash
# Calibration point: does the throughput keep rising above max_ongoing_requests=64?
set -uo pipefail
export PATH=/root/miniconda3/bin:$PATH
export PYTHONPATH=/root/hw3/src
cd /root/hw3
mkdir -p results/B_candidates/calibration-128 logs

bash scripts/run_group.sh B3_calibration B3_max128_run1 results/B_candidates/calibration-128
code=$?

echo "=== B calibration summary ==="
python - <<'PY'
import json
from pathlib import Path
for label, rel in [
    ("A(mor=5)", "A_default"),
    ("B1(mor=16)", "B_candidates/candidate-1"),
    ("B2(mor=64)", "B_candidates/candidate-2"),
    ("B3(mor=128)", "B_candidates/calibration-128"),
]:
    path = Path("results") / rel / "summary.json"
    if not path.exists():
        print(label, "MISSING"); continue
    s = json.loads(path.read_text())
    print(
        f"{label}: ok={s['successful']} thr={s['throughput_rps']:.2f} elapsed={s['elapsed_s']:.1f} "
        f"cache={s['cache_hit_rate']*100:.1f}% prefill={s['computed_prefill_tokens_total']} "
        f"ttft p50={s['ttft_s']['p50']:.1f} p95={s['ttft_s']['p95']:.1f} p99={s['ttft_s']['p99']:.1f} "
        f"e2e p95={s['latency_s']['p95']:.1f} tpot_p95={s['tpot_s']['p95']:.4f}"
    )
PY
echo "B3_DONE exit=$code"
