#!/usr/bin/env bash
# Orchestrator: wait for the model, start the cluster, smoke test, then batch 1.
# Everything is appended to logs/pipeline.log and a machine readable
# run/status.json so the local driver can follow progress.
set -uo pipefail
export PATH=/root/miniconda3/bin:$PATH
export PYTHONPATH=/root/hw3/src
cd /root/hw3
mkdir -p logs run report results

LOG=logs/pipeline.log
MODEL_DIR=/root/autodl-tmp/models/Qwen3-4B-Instruct-2507

status() { # status <state> <detail>
  printf '{"state":"%s","detail":"%s","ts":"%s"}\n' "$1" "$2" "$(date -Is)" > run/status.json
  echo "[$(date +%H:%M:%S)] $1 :: $2" >> "$LOG"
}

status "waiting_model" "waiting for download to finish"
for i in $(seq 1 240); do
  if [ -f "$MODEL_DIR/model.safetensors.index.json" ] \
     && ! ls "$MODEL_DIR"/*.incomplete >/dev/null 2>&1 \
     && [ "$(ls "$MODEL_DIR"/model-0000*-of-00003.safetensors 2>/dev/null | wc -l)" -eq 3 ]; then
    break
  fi
  sleep 15
done
if ls "$MODEL_DIR"/*.incomplete >/dev/null 2>&1; then
  status "failed" "model download did not finish"
  exit 1
fi
status "model_ready" "$(du -sh "$MODEL_DIR" | cut -f1)"
python -c "import json;json.load(open('$MODEL_DIR/config.json'));print('config ok')" >> "$LOG" 2>&1

# plotting dependency (used for the report figures only)
python -c "import matplotlib" 2>/dev/null || pip install -q matplotlib >> "$LOG" 2>&1
python -c "import matplotlib;print('matplotlib', matplotlib.__version__)" >> "$LOG" 2>&1

# ---------------------------------------------------------------- cluster up
status "starting_cluster" "ray head + 4 workers, 4 sglang servers"
bash scripts/start_experiment.sh >> "$LOG" 2>&1
if ! grep -q "\[setup\] ready:" logs/start_experiment.log 2>/dev/null; then
  status "failed" "cluster or sglang startup failed"
  tail -60 logs/start_experiment.log >> "$LOG" 2>&1
  exit 2
fi
status "cluster_ready" "4 sglang backends healthy"

# ------------------------------------------------------------------ smoke
python -m hw3.smoke_test >> "$LOG" 2>&1
if ! grep -q '"ok": true' run/smoke.json 2>/dev/null; then
  status "failed" "smoke test failed"
  cat run/smoke.json >> "$LOG" 2>&1
  exit 3
fi
status "smoke_ok" "nodes/health/flush/SSE/prefix-cache all good"

# ------------------------------------------------------------------ batch 1
status "batch1" "A, B1, B2"
bash scripts/run_batch1.sh >> "$LOG" 2>&1
code=$?
status "batch1_done" "exit=$code"
exit $code
