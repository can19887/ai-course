#!/usr/bin/env bash
# Run one experiment group: deploy the policy, flush caches, replay, verify.
#
#   scripts/run_group.sh <policy> <run-name> <output-dir> [extra metadata ...]
#
# example:
#   scripts/run_group.sh A_default A_default_run1 /root/hw3/results/A_default
set -uo pipefail
export PATH=/root/miniconda3/bin:$PATH
export PYTHONPATH=/root/hw3/src
cd /root/hw3

POLICY=${1:?policy}
RUN_NAME=${2:?run-name}
OUT_DIR=${3:?output-dir}
shift 3

mkdir -p "$OUT_DIR" /root/hw3/logs
LOG="/root/hw3/logs/run_${RUN_NAME}.log"

EXTRA=()
for item in "$@"; do EXTRA+=(--metadata "$item"); done

echo "[run_group] policy=$POLICY run=$RUN_NAME out=$OUT_DIR log=$LOG"
python -u -m hw3.run_group \
  --policy "$POLICY" \
  --run-name "$RUN_NAME" \
  --output-dir "$OUT_DIR" \
  "${EXTRA[@]}" 2>&1 | tee "$LOG"
code=${PIPESTATUS[0]}
echo "[run_group] exit=$code"
exit "$code"
