#!/usr/bin/env bash
# Finalise the experiment matrix.
#  * D is re-run with the selected admission ratio (0.3)
#  * the looser variant (0.7) is kept as the D parameter study
#  * everything is aggregated into the report tables / figures / numbers
set -uo pipefail
export PATH=/root/miniconda3/bin:$PATH
export PYTHONPATH=/root/hw3/src
cd /root/hw3
mkdir -p results/D_variants/relaxed-0.7 logs report/fig

# keep the previous ratio=0.7 run as the parameter-study data point
if [ -f results/D_improved/summary.json ] && [ ! -f results/D_variants/relaxed-0.7/summary.json ]; then
  mv results/D_improved/* results/D_variants/relaxed-0.7/ 2>/dev/null || true
fi

bash scripts/run_group.sh D_improved D_improved_run1 results/D_improved
code_d=$?

python -m hw3.aggregate --results results
python -m hw3.make_numbers --results results --out report/numbers.json
python -m hw3.make_figures --results results --out report/fig

python /root/hw3/26fall-HW-data/workloads/hw2/target3-routing-policies/compare_runs.py \
  --baseline A \
  --run A=results/A_default/summary.json \
  --run B1=results/B_candidates/candidate-1/summary.json \
  --run B2=results/B_candidates/candidate-2/summary.json \
  --run C=results/C_affinity/summary.json \
  --run D=results/D_improved/summary.json \
  --output results/comparison/comparison.json > /dev/null 2>&1
echo "compare_runs exit=$?"

echo "=== FINAL MATRIX ==="
python - <<'PY'
import json
from pathlib import Path
rows = [
    ("A   p2c mor=5   ", "A_default"),
    ("B1  p2c mor=16  ", "B_candidates/candidate-1"),
    ("B2  p2c mor=64  ", "B_candidates/candidate-2"),
    ("B3  p2c mor=128 ", "B_candidates/calibration-128"),
    ("C   hash mor=64 ", "C_affinity"),
    ("D   affinity 0.3", "D_improved"),
    ("D'  affinity 0.7", "D_variants/relaxed-0.7"),
]
for label, rel in rows:
    path = Path("results") / rel / "summary.json"
    if not path.exists():
        print(label, "MISSING"); continue
    s = json.loads(path.read_text())
    dist = s["backend_distribution"]
    tot = sum(dist.values())
    print(
        f"{label} ok={s['successful']:4d} thr={s['throughput_rps']:6.2f} "
        f"cache={s['cache_hit_rate']*100:5.1f}% prefill={s['computed_prefill_tokens_total']:7d} "
        f"ttft p50={s['ttft_s']['p50']:6.2f} p95={s['ttft_s']['p95']:6.2f} "
        f"e2e p95={s['latency_s']['p95']:6.2f} maxshare={max(dist.values())/tot*100:5.1f}%"
    )
PY
echo "FINALISE_DONE D=$code_d"
