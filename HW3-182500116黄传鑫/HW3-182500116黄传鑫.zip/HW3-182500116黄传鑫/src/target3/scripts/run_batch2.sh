#!/usr/bin/env bash
# Batch 2: C (built-in ConsistentHashRouter) and D (custom prefix-affinity router),
# both with the B-selected max_ongoing_requests.  B was fixed to 64: throughput
# plateaus there (39.9-40.2 req/s at mor=64 and mor=128) while p95 stops
# improving, so 64 is the throughput-optimal, latency-neutral choice.
set -uo pipefail
export PATH=/root/miniconda3/bin:$PATH
export PYTHONPATH=/root/hw3/src
cd /root/hw3
mkdir -p results/C_affinity results/D_improved logs

bash scripts/run_group.sh C_affinity C_affinity_run1 results/C_affinity
code_c=$?
bash scripts/run_group.sh D_improved D_improved_run1 results/D_improved
code_d=$?

echo "=== batch2 summary ==="
python - <<'PY'
import json
from pathlib import Path
for label, rel in [
    ("A(mor=5)", "A_default"),
    ("B1(mor=16)", "B_candidates/candidate-1"),
    ("B2(mor=64)", "B_candidates/candidate-2"),
    ("C(mor=64,hash)", "C_affinity"),
    ("D(mor=64,custom)", "D_improved"),
]:
    path = Path("results") / rel / "summary.json"
    if not path.exists():
        print(label, "MISSING"); continue
    s = json.loads(path.read_text())
    print(
        f"{label}: ok={s['successful']} thr={s['throughput_rps']:.2f} elapsed={s['elapsed_s']:.1f} "
        f"cache={s['cache_hit_rate']*100:.1f}% prefill={s['computed_prefill_tokens_total']} "
        f"ttft p50={s['ttft_s']['p50']:.2f} p95={s['ttft_s']['p95']:.2f} "
        f"e2e p95={s['latency_s']['p95']:.2f} backends={s['backend_distribution']}"
    )
PY
echo "BATCH2_DONE C=$code_c D=$code_d"
