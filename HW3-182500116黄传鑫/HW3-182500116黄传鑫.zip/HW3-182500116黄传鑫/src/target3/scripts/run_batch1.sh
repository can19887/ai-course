#!/usr/bin/env bash
# Batch 1: B1 and B2 candidates (group A was run first and already validated).
set -uo pipefail
export PATH=/root/miniconda3/bin:$PATH
export PYTHONPATH=/root/hw3/src
cd /root/hw3
mkdir -p results/B_candidates/candidate-1 results/B_candidates/candidate-2 logs

bash scripts/run_group.sh B1_candidate B1_max16_run1 results/B_candidates/candidate-1
code_b1=$?
bash scripts/run_group.sh B2_candidate B2_max64_run1 results/B_candidates/candidate-2
code_b2=$?

echo "=== batch1 summary ==="
python - <<'PY'
import json
from pathlib import Path
for label, rel in [("A", "A_default"), ("B1", "B_candidates/candidate-1"), ("B2", "B_candidates/candidate-2")]:
    path = Path("results") / rel / "summary.json"
    if not path.exists():
        print(label, "MISSING"); continue
    s = json.loads(path.read_text())
    print(
        f"{label}: ok={s['successful']}/{s['requests']} fail={s['failed']} inc={s['incomplete']} "
        f"thr={s['throughput_rps']:.2f} elapsed={s['elapsed_s']:.1f} "
        f"cache={s['cache_hit_rate']*100:.1f}% prefill={s['computed_prefill_tokens_total']} "
        f"ttft p50={s['ttft_s']['p50']:.1f} p95={s['ttft_s']['p95']:.1f} "
        f"e2e p95={s['latency_s']['p95']:.1f} "
        f"lag_p95={s['dispatch_lag_s']['p95']:.3f} cq_p95={s['client_queue_s']['p95']:.3f}"
    )
    print("   backends", s['backend_distribution'], "errors", s['validation_errors'])
PY
echo "BATCH1_DONE B1=$code_b1 B2=$code_b2"
