# HW3（挑战三）：比较并改进 RayServe 路由

四副本 Ray Serve 服务 + 四个独立 SGLang 后端，在同一台 4×RTX 4090 服务器上用
`ray.cluster_utils.Cluster` 搭建「1 个 head 节点 + 4 个逻辑 worker 节点」，比较
A / B1 / B2 / C / D 五组路由配置，全部通过同一个 Ray Serve HTTP 入口回放课程固定负载。

```
Client ──HTTP──▶ Ray Serve HTTP Proxy ──▶ Replica 0..3 ──HTTP/SSE──▶ SGLang 0..3
                 (head 节点)               (4 个 worker 节点,     (每张 GPU 一个)
                                            每个节点 1 个)
```

> 提交包内路径以本文件所在目录（`HW3-182500116黄传鑫/`）为根，下面所有相对路径都相对该根目录。

## 1. 环境

| 项目 | 版本 |
| --- | --- |
| GPU | 4 × NVIDIA GeForce RTX 4090 24GB（同一台服务器） |
| 驱动 / CUDA | NVIDIA-SMI 595.71.05 / CUDA 13.2（容器内 CUDA runtime 12.8） |
| OS | Ubuntu 22.04.5 LTS, 224 vCPU, 754GB RAM |
| Python | 3.12（/root/miniconda3） |
| PyTorch | 2.9.1+cu128 |
| SGLang | 0.5.6.post2（attention backend: flashinfer 0.5.3, page-size 1） |
| Ray | 2.59.0（`ray[serve]`） |
| 模型 | Qwen/Qwen3-4B-Instruct-2507（≈8GB，四个后端各加载一份） |

SGLang 后端统一启动命令（正式实验期间四个后端一致，日志原文见 `results/target3/NOTES.md`）：

```bash
python -m sglang.launch_server \
  --model-path /root/autodl-tmp/models/Qwen3-4B-Instruct-2507 \
  --host 0.0.0.0 --port 30000 --attention-backend flashinfer --page-size 1 \
  --mem-fraction-static 0.75 --max-running-requests 32 --chunked-prefill-size 4096 \
  --schedule-policy fcfs --enable-cache-report --enable-metrics --trust-remote-code
```

## 2. 安装

```bash
# 1) 依赖（在 GPU 服务器上），完整清单见 src/target3/requirements.txt
pip install torch==2.9.1 torchvision==0.24.1 torchaudio==2.9.1 \
    --index-url https://download.pytorch.org/whl/cu128
pip install "sglang==0.5.6.post2" "ray[serve]==2.59.0" aiohttp

# 2) 课程固定负载（官方脚本原样复制在 src/target3/workload/，用于复现，未做任何修改）
git clone https://github.com/Zirkland/26fall-HW-data.git /root/hw3/26fall-HW-data
cd /root/hw3/26fall-HW-data/workloads/hw2/target3-routing-policies
pip install -r requirements.txt
python validate_workload.py mooncake_prefix_workload_v2_seed2026.jsonl
# 期望：sha256 f154ba954e28ca9612257edf5deb0d5dfc6bf27fd0115a701e1f49e52df75b03
#       families 64 / warmups 64 / measured 2048 / planned_duration_s 29.538768

# 3) 本提交的代码（放进服务器上同一个目录，脚本默认从 /root/hw3 运行）
scp -r src/target3 root@<host>:/root/hw3/
```

模型下载（大陆网络用 ModelScope 镜像，实测比 hf-mirror 快约 8 倍）：

```bash
python -c "from modelscope import snapshot_download; \
  snapshot_download('Qwen/Qwen3-4B-Instruct-2507', \
  local_dir='/root/autodl-tmp/models/Qwen3-4B-Instruct-2507')"
```

固定负载数据文件 `mooncake_prefix_workload_v2_seed2026.jsonl`（约 64MB）未打进提交包，
按上面的 `git clone` 获取即可；生成器与结果文件里都记录了它的 SHA-256，可自行校验。

## 3. 启动与回放命令

```bash
cd /root/hw3
export PYTHONPATH=/root/hw3/src

# (1) 起逻辑集群（1 head + 4 worker）与 4 个 SGLang 后端，等待全部 /health 通过
bash src/target3/scripts/start_experiment.sh
python -m hw3.smoke_test            # 自检：节点数 / 健康 / 清缓存 / SSE / 前缀缓存命中

# (2) 逐组实验：部署本组 Ray Serve 配置 → 校验四副本↔四节点↔四后端 → 清空四个后端缓存
#     → 回放 64 条预热 + 2048 条测量请求 → 校验结果
cd src/target3
bash scripts/run_group.sh A_default     A_default_run1     /root/hw3/results/A_default
bash scripts/run_group.sh B1_candidate  B1_max16_run1      /root/hw3/results/B_candidates/candidate-1
bash scripts/run_group.sh B2_candidate  B2_max64_run1      /root/hw3/results/B_candidates/candidate-2
bash scripts/run_group.sh C_affinity    C_affinity_run1    /root/hw3/results/C_affinity
bash scripts/run_group.sh D_improved    D_improved_run1    /root/hw3/results/D_improved

# (3) 汇总（生成报告主表 / 分阶段表 / 分层表 / 后端分布表）
cd /root/hw3
python -m hw3.aggregate --results results
python -m hw3.make_numbers --results results --out report/numbers.json
python -m hw3.make_all_figures
```

每轮 `run_group.sh` 会依次：停止上一轮 Serve 应用 → 用本组参数重新 `serve.run` → 探测
`/health` 校验四个 Replica 分别落在四个节点、对应四个后端（不满足则重新部署，最多 6 次）
→ 对四个后端逐个 `POST /flush_cache` 并确认 200 → 启动流量发生器
（`run_workload.py --policy serve`，只负责回放与测量）→ 校验验收条件。
回放结束后会把 SGLang 的真实模型与启动命令写入该轮结果文件（见 `results/target3/NOTES.md` 第 1 节）。

## 4. 脚本与代码用途

| 路径 | 作用 |
| --- | --- |
| `src/target3/hw3/cluster.py` | 用 `ray.cluster_utils.Cluster` 建 1 head + 4 worker，写 `run/topology.json`；每个 worker 带私有自定义资源 `worker_i` 用于精确钉节点 |
| `src/target3/hw3/sglang_launcher.py` | 每个 worker 节点起 1 个 `sglang.launch_server`（`CUDA_VISIBLE_DEVICES` 固定），健康检查与 `/flush_cache` |
| `src/target3/hw3/serve_app.py` | Ray Serve Deployment `RayServeHTTP`（4 replicas），`POST /generate` 转发 SSE，写入 `X-Ray-Replica-ID / X-Ray-Node-ID / X-SGLang-Backend` |
| `src/target3/hw3/routers.py` | D 组自定义路由器 `PrefixAffinityRouter`（前缀亲和 + 负载保护） |
| `src/target3/hw3/policies.py` | A/B1/B2/B3/C/D/D′ 各组的 Ray Serve 路由配置 |
| `src/target3/hw3/run_group.py` | 一组实验的完整流程：停旧应用 → 部署 → 校验映射 → 清缓存 → 回放 → 校验结果 |
| `src/target3/hw3/run_experiment.py` | 部署/回放/校验的公共函数，含 `stamp_served_model()`（把真实模型写进结果文件） |
| `src/target3/hw3/smoke_test.py` | 环境自检（节点数 / 健康 / 缓存清空 / SSE / 前缀缓存命中） |
| `src/target3/hw3/aggregate.py`、`make_numbers.py`、`make_all_figures.py` | 汇总表、分析数据与报告插图 |
| `src/target3/scripts/start_experiment.sh` | 一键起集群与四个后端（可 `MAXRUN=` 覆盖后端并发） |
| `src/target3/scripts/run_group.sh` | 一键跑一组实验 |
| `src/target3/scripts/run_batch1.sh`、`run_batch2.sh`、`run_b3.sh`、`run_d_variants.sh`、`finalise.sh` | 批量跑各组实验的编排脚本 |
| `src/target3/scripts/pipeline1.sh`、`pipeline2.sh` | 服务器上的自动化流水线（等待模型 → 起集群 → 自检 → 跑组） |
| `src/target3/sync.cmd` | 本地代码同步到服务器（Windows 端） |
| `src/target3/workload/` | 课程官方负载脚本（原样复制，未修改） |

## 5. 结果目录与报告表格的对应关系

```
results/target3/
├── A_default/                        → 报告主表 A 列
├── B_candidates/candidate-1/         → 报告主表 B1 列
├── B_candidates/candidate-2/         → 报告主表 B2 列（B 组选定值 64）
├── B_candidates/calibration-128/     → 正文 3.1 的 B3 标定点
├── C_affinity/                       → 报告主表 C 列
├── D_improved/                       → 报告主表 D 列
├── D_variants/relaxed-0.7/           → 正文 3.3 的探索性观察（阈值 0.7）
├── D_variants/tight-0.3/             → 阈值 0.3 的重复点
├── comparison/                       → 汇总表（报告主表/分阶段/分层/后端分布）与课程对照工具输出
├── evidence/                         → topology.json、smoke.json、gpu_samples.jsonl
└── NOTES.md                          → 记录勘误（模型字段、max_running_requests）与核对方法
```

每个实验目录包含流量发生器生成的原始文件与运行记录：

| 文件 | 内容 |
| --- | --- |
| `config.json` | 命令、模型、路由器、并发参数、负载 SHA-256、元数据、`sglang_command` |
| `warmups.csv` | 64 条预热请求逐请求结果 |
| `requests.csv` | 2048 条测量请求逐请求结果（报告里所有 p95 都能在这里复算） |
| `summary.json` | 全程 / 分阶段 / 分层汇总指标 |
| `deploy.json` | 本轮 replica→node→backend 映射、部署重试记录、`/flush_cache` 返回 |
| `run_meta.json` | 本组策略、验收结论、GPU 采样汇总、实际服务的模型与启动命令 |

## 6. 复现与口径说明

* 五组实验使用同一份负载（SHA-256 已校验）、同一模型与 SGLang 参数、同一四副本拓扑，
  只有 Ray Serve 路由配置不同。
* 每组实验前都重新部署 Serve 配置并清空四个后端缓存，因此每轮都是冷缓存起步。
* 路由器只看当前请求（`X-Session-Id` / `X-Prefix-Family` 头）与当前服务状态
  （副本队列长度、在途请求数），不使用任何未来请求信息。
* **记录勘误**：流量发生器 `run_workload.py` 没有 `--model` 参数，其写出的 `model` 字段是内置
  默认值而非真实模型；交付包中的结果文件已更正为实际服务的
  Qwen/Qwen3-4B-Instruct-2507，并保留原值与完整启动命令。正式实验期间后端
  `--max-running-requests=32`。详见 `results/target3/NOTES.md`。
* 轮次：A/B1/B2/B3/C/D/D′ 各 1 轮。若要考察轮间波动，在对应目录下建 `run-1/`、`run-2/`
  子目录重复实验，`aggregate.py` 会自动取均值并给出范围。
* 目标一（target1）：所给《第三次挑战.pdf》只描述目标三，未提供目标一的题目与固定负载，
  因此本次提交不包含 target1 的实验结果（`src/target1/README.md` 有说明）。
