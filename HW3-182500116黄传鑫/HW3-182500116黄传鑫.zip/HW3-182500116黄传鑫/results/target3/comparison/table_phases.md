| 配置 | 阶段 | 成功请求 | 缓存命中率 | TTFT p95 (s) | E2E p95 (s) |
|---|---|---|---|---|---|
| A_default | steady | 512.0000 | 0.7134 | 35.5446 | 37.7028 |
| A_default | burst | 1024.0000 | 0.8591 | 110.3914 | 111.7298 |
| A_default | recovery | 512.0000 | 0.8469 | 137.2433 | 138.7582 |
| B1_candidate | steady | 512.0000 | 0.7601 | 6.2658 | 8.6648 |
| B1_candidate | burst | 1024.0000 | 0.8596 | 28.3735 | 30.8362 |
| B1_candidate | recovery | 512.0000 | 0.8412 | 38.5527 | 40.5853 |
| B2_candidate | steady | 512.0000 | 0.7228 | 0.5394 | 4.8351 |
| B2_candidate | burst | 1024.0000 | 0.8520 | 16.2105 | 19.5668 |
| B2_candidate | recovery | 512.0000 | 0.8441 | 20.8125 | 23.5794 |
| B_calibration_128 | steady | 512.0000 | 0.7595 | 0.2179 | 4.5173 |
| B_calibration_128 | burst | 1024.0000 | 0.8397 | 14.5861 | 17.9551 |
| B_calibration_128 | recovery | 512.0000 | 0.8512 | 19.7374 | 22.9126 |
| C_affinity | steady | 512.0000 | 0.9545 | 39.1022 | 42.0794 |
| C_affinity | burst | 1024.0000 | 0.9580 | 72.4805 | 74.8712 |
| C_affinity | recovery | 512.0000 | 0.9592 | 71.5965 | 74.3023 |
| D_improved | steady | 512.0000 | 0.9226 | 1.4210 | 4.8667 |
| D_improved | burst | 1024.0000 | 0.8272 | 22.8761 | 26.1328 |
| D_improved | recovery | 512.0000 | 0.8232 | 23.2758 | 25.8805 |
| D_variant_relaxed-0.7 | steady | 512.0000 | 0.9070 | 1.3208 | 4.5787 |
| D_variant_relaxed-0.7 | burst | 1024.0000 | 0.8109 | 22.7408 | 25.8434 |
| D_variant_relaxed-0.7 | recovery | 512.0000 | 0.8130 | 23.4852 | 26.3460 |
| D_variant_tight-0.3 | steady | 512.0000 | 0.9082 | 1.4388 | 4.7871 |
| D_variant_tight-0.3 | burst | 1024.0000 | 0.8169 | 22.3141 | 24.9958 |
| D_variant_tight-0.3 | recovery | 512.0000 | 0.8564 | 23.2737 | 25.6902 |
