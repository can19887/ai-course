# 测量记录说明与勘误（NOTES）

本文件记录评审中发现的三处**记录问题**及其更正依据。所有更正只涉及“元数据字段”，
**没有改动任何测量数据**：`requests.csv`、`warmups.csv` 的每一行、以及 `summary.json`
中的吞吐、延迟、缓存命中、token 计数等统计量都保持原样。

## 1. 模型字段与实际服务模型不一致（已更正）

**现象**：8 个运行目录的 `config.json` / `summary.json` 顶层 `model` 字段都写着
`Qwen/Qwen3-0.6B`，与报告及 `config.json.metadata.model` 中的
`Qwen/Qwen3-4B-Instruct-2507` 矛盾。

**原因**：课程流量发生器 `run_workload.py` 没有 `--model` 命令行参数，它总是把自己内置的
默认值写进 `model` 字段；回放命令无法覆盖，因此该字段记录的不是真实服务的模型。

**实际服务的模型由启动日志证明**：四个后端的启动命令行（`sglang-gpu0..3.log` 第一行）为

```
/root/miniconda3/bin/python -m sglang.launch_server \
  --model-path /root/autodl-tmp/models/Qwen3-4B-Instruct-2507 \
  --host 0.0.0.0 --port 30000 --attention-backend flashinfer --page-size 1 \
  --mem-fraction-static 0.75 --max-running-requests 32 --chunked-prefill-size 4096 \
  --schedule-policy fcfs --enable-cache-report --enable-metrics \
  --trust-remote-code --log-level warning
```

**更正方式**：每个 `config.json` / `summary.json` 的 `model` 字段改为
`Qwen/Qwen3-4B-Instruct-2507`，原值保留在 `model_recorded_by_generator`，
并在 `model_note` 中说明原因；同时把完整启动命令行写入 `sglang_command` 字段，
使“后端用什么配置启动的”可以从结果文件本身核对，而不只依赖日志。

**后续脚本已修正**：`src/target3/hw3/run_experiment.py` 中的
`stamp_served_model()` 会在每轮回放结束后，把 SGLang 的真实模型与启动命令写入发生器产出的
两个 json 文件，避免同类记录错误再次发生。

## 2. `max_running_requests` 的实际取值（已更正）

报告此前写“正式五组统一使用 `max_running_requests=256`”，这是**错的**。

启动日志显示正式实验期间四个后端都是 **`--max-running-requests 32`**（见上面的命令行）。
时间线：先用 256 启动过一次集群，随后为了对比把集群以 32 重启
（`MAXRUN=32 bash scripts/start_experiment.sh`），此后 A、B1、B2、B3、C、D 与两个 D 变体
都在这次“32”的集群上运行；A 组因此还额外留下了一个在 256 配置下测得的旧目录
（运行名 `A_maxrun32_run1`，实际发生在 256 阶段，命名有误），报告采用的是 32 配置下的
`A_maxrun32_run1` 结果。

补充说明：报告曾用“256 与 32 两轮吞吐一致（12.08 与 12.13 req/s）”来论证批大小不是瓶颈，
这个对比本身**成立**（两轮确实是同一台机器上两种 `max_running_requests` 的结果），
但“正式组用的是 256”这一句必须改为 32。原始数据没有删除，256 那一轮仍在
`dist` 之前的 `logs/run_A_default_run1.log`（`replay_seconds=177.62`）中留有痕迹，
只是其 `results` 目录已被后一轮覆盖。

## 3. GPU 采样与运行目录的对应关系

`run_meta.json.gpu_summary` 是每轮实验自己的 GPU 采样汇总（A 82 个样本、B2 28 个、C 52 个、
D 28 个，每 2 秒一次）。原始采样文件在服务器上是**每轮一份**、位于运行工作目录，打包时只有
最后一轮的那份被带回本地，也就是本目录中的 `report/run/gpu_samples.jsonl`。
因此报告不再声称“逐轮原始采样已随包提交”，改为说明：逐轮汇总在每个
`run_meta.json` 中，随包的 `gpu_samples.jsonl` 对应最后一次运行。

## 4. 其他口径说明

* `run_meta.json.replay_seconds`（含预热与部署等待）比 `summary.json.elapsed_s`
  （仅测量阶段）大约多 8–9 秒，两者不要混用；报告中的吞吐一律使用 `elapsed_s`。
* 报告中对 A 组瓶颈的表述已按评审意见改写：`max_ongoing_requests=5` 限制的是
  **请求级并发与调度容量**，其直接后果是 Serve 侧排队与极高 TTFT；GPU 利用率与 TPOT
  只能说明批处理形态发生变化，**不足以单独证明 GPU 计算不是限制因素**。
* 报告中对 D 组阈值（0.3 / 0.7）的比较已改称“探索性观察”：两者各只跑了一轮，
  且 rendezvous 哈希使用 Replica ID，重新部署后 Replica ID 变化会改变热点前缀族的归属，
  因此不能据一轮数据得出稳定的阈值规律。
