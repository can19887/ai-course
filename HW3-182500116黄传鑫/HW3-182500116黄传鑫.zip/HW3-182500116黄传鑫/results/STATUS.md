# 实验状态

本目录包含挑战三的正式 GPU 实测数据：A / B1 / B2 / C / D 各 1 轮，每轮 64 条预热 + 2048 条测量请求，全部 success=2048 / fail=0 / incomplete=0，四个 Replica、四个 Ray 节点、四个 SGLang 后端均被覆盖。
另有 B3（max_ongoing_requests=128）与 D 的两个阈值变体作为标定数据。
硬件：4×RTX 4090 24GB、Ubuntu 22.04、Ray 2.59.0、SGLang 0.5.6.post2、模型 Qwen/Qwen3-4B-Instruct-2507、后端 --max-running-requests 32。

元数据勘误（模型字段、max_running_requests）与核对方法见 `target3/NOTES.md`。
