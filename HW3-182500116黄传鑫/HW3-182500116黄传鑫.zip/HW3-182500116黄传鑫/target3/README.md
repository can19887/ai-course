# target3：比较并改进 RayServe 路由

| 内容 | 位置 |
| --- | --- |
| 集群 / SGLang / Ray Serve / 路由策略代码 | `../src/target3/hw3/` |
| 启动与实验脚本 | `../src/target3/scripts/` |
| 官方负载脚本（原样复制，只读） | `../src/target3/workload/` |
| A 组 | `../results/target3/A_default/` |
| B 两个候选 + 128 标定 | `../results/target3/B_candidates/` |
| C 组（一致性哈希） | `../results/target3/C_affinity/` |
| D 组（自定义前缀亲和 + 负载保护） | `../results/target3/D_improved/` |
| D 参数研究（阈值 0.7 / 0.3） | `../results/target3/D_variants/` |
| 汇总表与课程对照工具输出 | `../results/target3/comparison/` |

每组目录内含 `config.json`（命令与元数据）、`warmups.csv`、`requests.csv`（2048 行逐请求）、`summary.json`、`deploy.json`（replica→node→backend 映射与清缓存结果）、`run_meta.json`（GPU 采样与验收结论）。报告中的每个数字都可以在这些文件里复算。
