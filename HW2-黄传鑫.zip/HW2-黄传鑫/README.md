# 第二次挑战：SGLang 前缀缓存与请求流程

姓名：黄传鑫

## 1. 实验环境

- 操作系统：Windows + WSL2，Ubuntu 26.04 LTS
- GPU：NVIDIA GeForce RTX 5060 Laptop GPU，8 GB 显存
- NVIDIA Driver：592.15
- Python：3.12
- SGLang：0.5.14
- Ray：2.56.0
- PyTorch：2.11.0+cu130
- 模型：`Qwen/Qwen3-0.6B`

## 2. 环境安装

以下命令均在 WSL Ubuntu 中执行。

```bash
python3 -m venv ~/hw2-runtime/.venv
source ~/hw2-runtime/.venv/bin/activate
python -m pip install --upgrade pip
python -m pip install "sglang==0.5.14" "ray==2.56.0" aiohttp numpy transformers
```

实验使用的 PyTorch 为 CUDA 13.0 构建版本。安装完成后可运行：

```bash
python - <<'PY'
import ray, sglang, torch
print("SGLang:", sglang.__version__)
print("Ray:", ray.__version__)
print("PyTorch:", torch.__version__)
print("CUDA available:", torch.cuda.is_available())
print("GPU:", torch.cuda.get_device_name(0))
PY
```

## 3. 启动服务

```bash
source ~/hw2-runtime/.venv/bin/activate

python -m sglang.launch_server \
  --model-path Qwen/Qwen3-0.6B \
  --host 0.0.0.0 \
  --port 30000 \
  --attention-backend triton \
  --cuda-graph-backend-prefill disabled \
  --log-level info 2>&1 | tee server.log
```

本机 WSL 环境能够使用 GPU，但没有独立 CUDA Toolkit 的 `nvcc`，FlashInfer 的 Prefill CUDA Graph 初始化因此失败。实验改用 Triton attention backend，并关闭 Prefill CUDA Graph；Radix Cache 保持默认开启。服务日志出现 `Tree cache initialized: ... impl=RadixCache` 后即可运行测试。

## 4. 回放实验

新开一个 WSL 终端：

```bash
cd "/mnt/c/Users/bigmo/HW2-黄传鑫"
source ~/hw2-runtime/.venv/bin/activate

python src/target1/benchmark.py --group dispersed_prefix
python src/target1/benchmark.py --group shared_prefix
```

脚本通过原生 `/generate` 接口发送 `input_ids`，使用流式响应。每组包含 32 条测量请求，最大并发数为 8；每条输入 2112 tokens，输出 16 tokens，采样参数为 `temperature=0`、`ignore_eos=true`、`sampling_seed=2026`。

每组开始前脚本调用 `/flush_cache` 并确认成功。共享前缀组额外发送一条不计入结果的预热请求，使 2048-token 公共前缀进入 Radix Cache。分散前缀组的每条请求首 token 均不同，以避免前缀命中。

## 5. 代码与结果说明

- `src/target1/benchmark.py`：构造两组负载，清空缓存，执行并发流式请求，统计成功率、吞吐量、缓存命中率、实际 Prefill tokens、TTFT、TPOT 和 E2E，并写出逐请求及汇总结果。
- `results/target1/shared_prefix/requests.jsonl`：共享前缀组逐请求原始结果。
- `results/target1/shared_prefix/requests.csv`：共享前缀组逐请求表格。
- `results/target1/shared_prefix/summary.json`：共享前缀组汇总，对应报告任务一主表的 Shared 列。
- `results/target1/dispersed_prefix/requests.jsonl`：分散前缀组逐请求原始结果。
- `results/target1/dispersed_prefix/requests.csv`：分散前缀组逐请求表格。
- `results/target1/dispersed_prefix/summary.json`：分散前缀组汇总，对应报告任务一主表的 Dispersed 列。

汇总指标定义：

```text
cache_hit_rate = sum(cached_tokens) / sum(prompt_tokens)
actual_prefill_tokens = sum(prompt_tokens - cached_tokens)
TPOT = (E2E - TTFT) / (completion_tokens - 1)
```

## 6. 目录结构

```text
HW2-黄传鑫/
├── README.md
├── report.pdf
├── AI 使用说明情况（第二次挑战）.pdf
├── src/
│   └── target1/
│       └── benchmark.py
└── results/
    └── target1/
        ├── shared_prefix/
        │   ├── requests.csv
        │   ├── requests.jsonl
        │   └── summary.json
        └── dispersed_prefix/
            ├── requests.csv
            ├── requests.jsonl
            └── summary.json
```
