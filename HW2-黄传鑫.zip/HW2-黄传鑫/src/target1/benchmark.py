import argparse
import asyncio
import csv
import json
import time
from pathlib import Path

import aiohttp
import numpy as np
from transformers import AutoTokenizer


BASE_URL = "http://127.0.0.1:30000"
MODEL = "Qwen/Qwen3-0.6B"
NUM_REQUESTS = 32
CONCURRENCY = 8
PROMPT_TOKENS = 2112
PREFIX_TOKENS = 2048
OUTPUT_TOKENS = 16

SAMPLING_PARAMS = {
    "temperature": 0,
    "max_new_tokens": OUTPUT_TOKENS,
    "ignore_eos": True,
    "sampling_seed": 2026,
}


def repeat_to_length(token_ids, length):
    if not token_ids:
        raise ValueError("用于构造负载的 token 列表为空")
    repeated = token_ids * ((length // len(token_ids)) + 1)
    return repeated[:length]


def build_workloads():
    tokenizer = AutoTokenizer.from_pretrained(MODEL)

    prefix_seed = tokenizer.encode(
        "Prefix cache benchmark for deterministic language model inference. ",
        add_special_tokens=False,
    )
    suffix_seed = tokenizer.encode(
        "Continue this request with a deterministic response for measurement. ",
        add_special_tokens=False,
    )

    shared_prefix = repeat_to_length(prefix_seed, PREFIX_TOKENS)
    suffix_body = repeat_to_length(suffix_seed, 64)
    dispersed_body = repeat_to_length(prefix_seed + suffix_seed, PROMPT_TOKENS)

    special_ids = set(tokenizer.all_special_ids)
    unique_ids = sorted(
        {
            int(token_id)
            for token_id in tokenizer.get_vocab().values()
            if 256 <= int(token_id) < tokenizer.vocab_size
            and int(token_id) not in special_ids
        }
    )

    if len(unique_ids) < 65:
        raise RuntimeError("无法找到足够的普通 token ID")

    # 每个请求的第一个差异 token 都不同，避免后缀之间继续发生前缀命中。
    shared_requests = []
    dispersed_requests = []

    for request_id in range(NUM_REQUESTS):
        shared_suffix = [unique_ids[request_id]] + suffix_body[1:]
        shared_ids = shared_prefix + shared_suffix

        dispersed_ids = (
            [unique_ids[32 + request_id]] + dispersed_body[1:]
        )

        assert len(shared_ids) == PROMPT_TOKENS
        assert len(dispersed_ids) == PROMPT_TOKENS

        shared_requests.append(shared_ids)
        dispersed_requests.append(dispersed_ids)

    # 预热请求的后缀首 token 不同于全部测量请求，
    # 因此只预热共享的 2048-token 前缀。
    warmup_suffix = [unique_ids[64]] + suffix_body[1:]
    shared_warmup = shared_prefix + warmup_suffix
    assert len(shared_warmup) == PROMPT_TOKENS

    return shared_requests, dispersed_requests, shared_warmup


async def flush_cache(session):
    url = f"{BASE_URL}/flush_cache?timeout=30"
    async with session.post(url) as response:
        body = await response.text()

        if response.status != 200:
            raise RuntimeError(
                f"flush_cache 失败：HTTP {response.status}: {body}"
            )

        if "Cache flushed" not in body:
            raise RuntimeError(f"未确认缓存清空成功：{body}")

        print("缓存清空成功")


async def send_request(session, semaphore, request_id, input_ids):
    payload = {
        "input_ids": input_ids,
        "sampling_params": SAMPLING_PARAMS,
        "stream": True,
    }

    result = {
        "request_id": request_id,
        "success": False,
        "prompt_tokens": 0,
        "cached_tokens": 0,
        "completion_tokens": 0,
        "ttft_ms": None,
        "tpot_ms": None,
        "e2e_ms": None,
        "output_text": "",
        "error": None,
    }

    async with semaphore:
        start_time = time.perf_counter()
        first_token_time = None
        last_event_time = None
        final_event = None

        try:
            async with session.post(
                f"{BASE_URL}/generate", json=payload
            ) as response:
                if response.status != 200:
                    body = await response.text()
                    raise RuntimeError(
                        f"HTTP {response.status}: {body}"
                    )

                async for raw_line in response.content:
                    line = raw_line.decode("utf-8", errors="replace").strip()

                    if not line.startswith("data:"):
                        continue

                    data = line[len("data:"):].strip()

                    if data == "[DONE]":
                        break

                    event = json.loads(data)
                    event_time = time.perf_counter()

                    if "error" in event:
                        raise RuntimeError(str(event["error"]))

                    final_event = event
                    last_event_time = event_time
                    meta = event.get("meta_info") or {}

                    has_output = (
                        bool(event.get("text"))
                        or meta.get("completion_tokens", 0) > 0
                    )

                    if first_token_time is None and has_output:
                        first_token_time = event_time

            if final_event is None:
                raise RuntimeError("没有收到有效的流式 JSON 数据")

            if first_token_time is None or last_event_time is None:
                raise RuntimeError("未检测到生成 token")

            meta = final_event.get("meta_info") or {}
            prompt_tokens = int(meta.get("prompt_tokens", 0))
            cached_tokens = int(meta.get("cached_tokens", 0))
            completion_tokens = int(meta.get("completion_tokens", 0))

            end_to_end = last_event_time - start_time
            ttft = first_token_time - start_time

            if completion_tokens > 1:
                tpot = (end_to_end - ttft) / (completion_tokens - 1)
            else:
                tpot = 0.0

            result.update(
                {
                    "success": completion_tokens == OUTPUT_TOKENS,
                    "prompt_tokens": prompt_tokens,
                    "cached_tokens": cached_tokens,
                    "completion_tokens": completion_tokens,
                    "ttft_ms": ttft * 1000,
                    "tpot_ms": tpot * 1000,
                    "e2e_ms": end_to_end * 1000,
                    "output_text": final_event.get("text", ""),
                }
            )

            if completion_tokens != OUTPUT_TOKENS:
                result["error"] = (
                    f"输出长度为 {completion_tokens}，期望 {OUTPUT_TOKENS}"
                )

        except Exception as exc:
            result["error"] = repr(exc)

        return result


def percentile(values, q):
    return float(np.percentile(values, q)) if values else None


def make_summary(group, results, wall_time):
    successful = [item for item in results if item["success"]]

    prompt_sum = sum(item["prompt_tokens"] for item in successful)
    cached_sum = sum(item["cached_tokens"] for item in successful)
    completion_sum = sum(
        item["completion_tokens"] for item in successful
    )

    ttft = [item["ttft_ms"] for item in successful]
    tpot = [item["tpot_ms"] for item in successful]
    e2e = [item["e2e_ms"] for item in successful]

    return {
        "group": group,
        "num_requests": len(results),
        "successful_requests": len(successful),
        "success_rate": len(successful) / len(results),
        "concurrency": CONCURRENCY,
        "expected_prompt_tokens_per_request": PROMPT_TOKENS,
        "expected_completion_tokens_per_request": OUTPUT_TOKENS,
        "total_prompt_tokens": prompt_sum,
        "total_cached_tokens": cached_sum,
        "cache_hit_rate": (
            cached_sum / prompt_sum if prompt_sum else 0.0
        ),
        "actual_prefill_tokens": prompt_sum - cached_sum,
        "wall_time_seconds": wall_time,
        "request_throughput_rps": len(successful) / wall_time,
        "output_token_throughput_tps": completion_sum / wall_time,
        "ttft_ms_p50": percentile(ttft, 50),
        "ttft_ms_p95": percentile(ttft, 95),
        "tpot_ms_p50": percentile(tpot, 50),
        "tpot_ms_p95": percentile(tpot, 95),
        "e2e_ms_p50": percentile(e2e, 50),
        "e2e_ms_p95": percentile(e2e, 95),
    }


def save_results(output_dir, results, summary):
    output_dir.mkdir(parents=True, exist_ok=True)

    with (output_dir / "requests.jsonl").open(
        "w", encoding="utf-8"
    ) as file:
        for item in results:
            file.write(json.dumps(item, ensure_ascii=False) + "\n")

    with (output_dir / "requests.csv").open(
        "w", encoding="utf-8", newline=""
    ) as file:
        writer = csv.DictWriter(file, fieldnames=results[0].keys())
        writer.writeheader()
        writer.writerows(results)

    with (output_dir / "summary.json").open(
        "w", encoding="utf-8"
    ) as file:
        json.dump(summary, file, ensure_ascii=False, indent=2)


async def run(group):
    shared_requests, dispersed_requests, shared_warmup = (
        build_workloads()
    )

    if group == "shared_prefix":
        requests_to_run = shared_requests
    else:
        requests_to_run = dispersed_requests

    timeout = aiohttp.ClientTimeout(total=600)
    connector = aiohttp.TCPConnector(limit=CONCURRENCY)
    semaphore = asyncio.Semaphore(CONCURRENCY)

    async with aiohttp.ClientSession(
        timeout=timeout, connector=connector
    ) as session:
        # 此时没有尚未结束的请求，再执行 flush。
        await flush_cache(session)

        if group == "shared_prefix":
            print("发送共享前缀预热请求……")
            warmup_result = await send_request(
                session, asyncio.Semaphore(1), -1, shared_warmup
            )
            if not warmup_result["success"]:
                raise RuntimeError(
                    f"共享前缀预热失败：{warmup_result}"
                )
            print("共享前缀预热完成；该请求不计入结果")

        print(
            f"开始 {group}：{NUM_REQUESTS} 条请求，"
            f"最大并发数 {CONCURRENCY}"
        )

        batch_start = time.perf_counter()

        tasks = [
            asyncio.create_task(
                send_request(
                    session, semaphore, request_id, input_ids
                )
            )
            for request_id, input_ids in enumerate(requests_to_run)
        ]

        results = await asyncio.gather(*tasks)
        wall_time = time.perf_counter() - batch_start

    results.sort(key=lambda item: item["request_id"])
    summary = make_summary(group, results, wall_time)

    project_root = Path(
        "/mnt/c/Users/bigmo/HW2-黄传鑫"
    )
    output_dir = (
        project_root / "results" / "target1" / group
    )

    save_results(output_dir, results, summary)

    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(f"结果已保存到：{output_dir}")

    failures = [item for item in results if not item["success"]]
    if failures:
        print("失败请求：")
        for failure in failures:
            print(failure)
        raise SystemExit(1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--group",
        required=True,
        choices=["shared_prefix", "dispersed_prefix"],
    )
    args = parser.parse_args()
    asyncio.run(run(args.group))


if __name__ == "__main__":
    main()